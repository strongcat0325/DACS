-- MySQL dump 10.13  Distrib 5.1.62, for Win32 (ia32)
--
-- Host: localhost    Database: d2_xinwenxitong
-- ------------------------------------------------------
-- Server version	5.1.62-community

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `t_admin`
--

DROP TABLE IF EXISTS `t_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userID` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FKri7quj2chn4dhn1q1lpi6xcan` (`userID`) USING BTREE,
  CONSTRAINT `FKri7quj2chn4dhn1q1lpi6xcan` FOREIGN KEY (`userID`) REFERENCES `t_userinfo` (`userID`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_admin`
--

LOCK TABLES `t_admin` WRITE;
/*!40000 ALTER TABLE `t_admin` DISABLE KEYS */;
INSERT INTO `t_admin` VALUES (1,1);
/*!40000 ALTER TABLE `t_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_articel_type`
--

DROP TABLE IF EXISTS `t_articel_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_articel_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `UK_owaqbf9382ugwjupg1md9g037` (`name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_articel_type`
--

LOCK TABLES `t_articel_type` WRITE;
/*!40000 ALTER TABLE `t_articel_type` DISABLE KEYS */;
INSERT INTO `t_articel_type` VALUES (5,'人文科技'),(4,'体育新闻'),(1,'头条新闻'),(2,'社会热点'),(3,'综艺娱乐'),(6,'金融财经');
/*!40000 ALTER TABLE `t_articel_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_articel_type_words`
--

DROP TABLE IF EXISTS `t_articel_type_words`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_articel_type_words` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `name` varchar(64) NOT NULL COMMENT '类型名称',
  `words` longtext NOT NULL COMMENT '高频词数据',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_articel_type_words`
--

LOCK TABLES `t_articel_type_words` WRITE;
/*!40000 ALTER TABLE `t_articel_type_words` DISABLE KEYS */;
INSERT INTO `t_articel_type_words` VALUES (1,'人文科技',',App,渗透率,APP,用户,使用,亿部,中亚,王志勤,计算,宽带接入,媒体,阿拉木图,厂商,研究院,套餐,标准,通信,万户,视频,未读,努尔,光网,隐私,技术,信息,网络,蓝色,华为,有限公司,终端,该国,高质量,妹儿,发展,GAI,更新,中兴通讯,协议,陈运清,互联网,底座,开发者,联合,运营商,已读,同比,手机,个人信息,哈萨克斯坦,基建,表情,智能,承载,净增,中国联通,平台,天翼通,品鉴,苏丹,实验室,中国电信,测试,千兆,固定,消息,双千兆,数字,电信业务,边缘,获取,输入框,产品,微信,滑动,提升,世界,创新'),(2,'体育新闻','本赛季,国奥,本场,王重天,热身赛,教练,姜宇星,非常,比赛,队员,年轻,陈戌源,中国足协,合同,完成,领先,三分,外援,库里,联赛,天津,足总杯,进球,男篮,直布罗陀,阿根廷,小组,足球,快船,分差,英超,吉林,训练,雄鹿,王重,军团,传奇,杨程,韩乔生,帮助,出色,伦纳德,广州,集训,掘金,主教练,周通,板仓,追分,组建,球员,建英,判罚,专注,阿根廷队,比分,姜伟泽,胜利,滑板,头球,预赛,贵州省,面对,教学赛,摩尔,魔术,荷兰,公牛队,篮下,前锋,土耳其,足球报,勇士队,命中,马布里,本节,队伍,国足,曼城,津门虎,日本,强赛,乔治,冠军,两队,球队,拉脱维亚,阿圭罗,李安,吉林队,上场,本期,戈登'),(3,'军事','地区,移交,海军,迷阵,勇士,安置,克里米亚,部门,事故,胡冬梅,人事,前线,工作,练兵,忠于党,美国,参训,部队,和勇毅,美台,战场,战机,实战,旧址,红军,牺牲,战位,脱落,飞行,中练,报道,光影,体能训练,俄媒,海巡,吕康,档案,挥汗如雨,张凌豪,出难题,好好学习,训练场,合作,邀请,魏凤,化对表,退役,克里米亚半岛,顽强拼搏,军方,罹难,民警,中国,海上,集团军,台湾,赵宗刚,塞尔维亚,王环,台海,聚力,铁索,备忘录,云贵川,优秀,飞行员,宁夏,训练,泸定桥,永远,坦克,特战,陆航,擒敌,凭吊,捷克,签署,审核,毒剂,伤病残,战友,高薪,编队,俄罗斯,新兵,舱盖,官兵,试图,春意盎然,突防,战士,弹射,处置,士兵,乌克兰,想要,低空,战斗机,定格,南联盟,警务,使馆,全警,故障,空中,大渡桥横铁索寒,交错'),(4,'综艺娱乐','青春,海报,上仙,声音,淄博市,姐姐,张子枫,孩子,音乐剧,夏琳,该片,冰城,之上,端木,领衔主演,拍摄,淄博,玉昭令,喜爱,匪气,云龙,老师,西瓜,赛区,阿西,该剧,票加,伤痛,这部,李云杰,喜剧,姐弟,高中,不断,评审,蓬莱,好聚好散,刘潮,女孩,抓内,殷若昕,成长,镜子,案开庭,付燕妮,金遥源,扮演,游晓颖,赏金,选手,小演员,燕妮,排练,特拉,海选,张艺谋,观众,预告片,点映,山苍水润,导演,合约,浮显,林暐哲,MV,正邪,剧中,票共票,学习,饰演,谍战,广播中心,张译,活动,影业,联办,演员,采访,青峰,猫咪,电影,刘维,秦霄贤,朱媛媛,成都,演技,延期,悬崖,守卫,张宪臣,展颜,自动,角色,李朔天,父女,版权,情感,影片,一直'),(5,'金融财经','浙商,兴业银行,赋能,银行,同业,万亿元,营业,公司,天安,接管,社会,拨备,大变局,该行,财险,会计师,资金,信托,商业,不良贷款,时代,年初,上年,有限公司,下降,年度报告,责任,通行费,增长,企业,归母,政府,百分点,收到,比上,事务所,年末,年月日,为元,同比,运营,路桥,报告,重庆,持股,商行,国家,公告,高速,平台,十四五,本外币,实现,共计,累计,期末,收入,负债,增幅,亿元,存款,余额,入局,补助,去年末,相关,西水股份,金融,提升,充足率,金额');
/*!40000 ALTER TABLE `t_articel_type_words` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_article`
--

DROP TABLE IF EXISTS `t_article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_article` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `addDate` varchar(255) DEFAULT NULL,
  `caiCount` int(11) DEFAULT NULL,
  `content` text,
  `favCount` int(11) DEFAULT NULL,
  `imgFile` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `viewCount` int(11) DEFAULT NULL,
  `zanCount` int(11) DEFAULT NULL,
  `articelTypeId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FKen79so6rijg5fx7x4fl8brxnj` (`articelTypeId`) USING BTREE,
  CONSTRAINT `FKen79so6rijg5fx7x4fl8brxnj` FOREIGN KEY (`articelTypeId`) REFERENCES `t_articel_type` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_article`
--

LOCK TABLES `t_article` WRITE;
/*!40000 ALTER TABLE `t_article` DISABLE KEYS */;
INSERT INTO `t_article` VALUES (1,'2021-03-22 15:31:37',0,'<p><span style=\"font-size:12px;\">日前，四川广汉三星堆遗址新发掘黄金面具、神树、象牙等重要文物的消息，在考古界引起震动，并持续霸屏网络热搜榜。企查查数据显示，目前我国共有1676家考古相关企业，河南、陕西分别以233家、231家企业高居前两位，并大幅领先于其他省份，西安、郑州、北京则是排名前三的城市。2020年全年新注册企业96家，同比下降35%，今年前2月新增企业8家。</span></p><p><span style=\"font-size:12px;\">　　<strong>豫陕两省大幅领先，西安郑州北京位居城市前三</strong></span></p><div class=\"img_wrapper\"><span style=\"font-size:12px;\"><img src=\"https://n.sinaimg.cn/finance/crawl/273/w1070h803/20210322/d3ee-kmrcukz8582633.png\" alt=\"\" /><span class=\"img_descr\"></span></span></div><p><span style=\"font-size:12px;\">　　黄河流域是中华文明的摇篮。2020年度全国十大考古新发现入围名单中，河南和陕西各自入围3项，豫陕两个文物大省前10项入围名单包揽了60%。企查查数据显示，河南、陕西分别有考古相关企业233家和231家，大幅领先于其他省份。山东、江苏和湖北则分别以102家、92家和73家排名前五。</span></p><div class=\"img_wrapper\"><span style=\"font-size:12px;\"><img src=\"https://n.sinaimg.cn/finance/crawl/162/w550h412/20210322/6c99-kmrcukz8582679.png\" alt=\"\" /><span class=\"img_descr\"></span></span></div><p><span style=\"font-size:12px;\">　　从城市分布来看，企查查数据显示，西安作为世界四大古都之一，历史文化底蕴深厚，考古相关企业数量遥遥领先，共158家，郑州、北京、洛阳以及南京等城市皆为古都，分别有考古企业62家、47家、42家和23家。</span></p><p><span style=\"font-size:12px;\">　　<strong>2020年新注册企业96家，今年前2月新增8家</strong></span></p><div class=\"img_wrapper\"><span style=\"font-size:12px;\"><img src=\"https://n.sinaimg.cn/finance/crawl/163/w550h413/20210322/88e5-kmrcukz8582766.png\" alt=\"\" /><span class=\"img_descr\"></span></span></div><p><span style=\"font-size:12px;\">　　随着国家对文物保护和考古发掘的重视，2011年以来的十年之间，考古企业注册量呈波动递增趋势。企查查数据显示，2011年共注册相关企业15家，2019年达到了十年来的最高点，共147家，同比增长47%，2020年注册量降至96家，同比减少35%。</span></p><div class=\"img_wrapper\"><span style=\"font-size:12px;\"><img src=\"https://n.sinaimg.cn/finance/crawl/162/w550h412/20210322/fab5-kmrcukz8582830.png\" alt=\"\" /><span class=\"img_descr\"></span></span></div><p><span style=\"font-size:12px;\">　　企查查数据显示，2021年前两个月共注册考古相关企业8家，同比减少38%。从月度来看，一二月份分别新注册4家。</span></p><div class=\"img_wrapper\"><span style=\"font-size:12px;\"><img src=\"https://n.sinaimg.cn/finance/crawl/273/w1070h803/20210322/788e-kmrcukz8582886.png\" alt=\"\" /><span class=\"img_descr\"></span></span></div><p><span style=\"font-size:12px;\">　　从注册资本来看，企查查数据显示，考古相关企业规模大多较小，注册资本在100万元以内的企业数量最多，占比达43%，注册资本在100万-500万元和500万-1000万元的分别占26%和12%。</span></p><p><span style=\"font-size:12px;\">　　三星堆遗址的发掘工作，体现了多学科、多机构合作的优势。与此同时，各类以考古为核心业务的企业与社会组织，也在大规模地进入到考古工作中去，以帮助我国考古事业更为有效地发展。</span></p>',0,'2021032215313728958.jpg','三星堆新发现背后：我国共1676家考古相关企业 豫陕两省最多',0,0,5),(2,'2021-03-22 15:33:05',0,'<p><span style=\"font-size:12px;\">日前，四川广汉三星堆遗址新发掘黄金面具、神树、象牙等重要文物的消息，在考古界引起震动，并持续霸屏网络热搜榜。企查查数据显示，目前我国共有1676家考古相关企业，河南、陕西分别以233家、231家企业高居前两位，并大幅领先于其他省份，西安、郑州、北京则是排名前三的城市。2020年全年新注册企业96家，同比下降35%，今年前2月新增企业8家。</span></p><p><span style=\"font-size:12px;\">　　<strong>豫陕两省大幅领先，西安郑州北京位居城市前三</strong></span></p><div class=\"img_wrapper\"><span style=\"font-size:12px;\"><img src=\"https://n.sinaimg.cn/finance/crawl/273/w1070h803/20210322/d3ee-kmrcukz8582633.png\" alt=\"\" /><span class=\"img_descr\"></span></span></div><p><span style=\"font-size:12px;\">　　黄河流域是中华文明的摇篮。2020年度全国十大考古新发现入围名单中，河南和陕西各自入围3项，豫陕两个文物大省前10项入围名单包揽了60%。企查查数据显示，河南、陕西分别有考古相关企业233家和231家，大幅领先于其他省份。山东、江苏和湖北则分别以102家、92家和73家排名前五。</span></p><div class=\"img_wrapper\"><span style=\"font-size:12px;\"><img src=\"https://n.sinaimg.cn/finance/crawl/162/w550h412/20210322/6c99-kmrcukz8582679.png\" alt=\"\" /><span class=\"img_descr\"></span></span></div><p><span style=\"font-size:12px;\">　　从城市分布来看，企查查数据显示，西安作为世界四大古都之一，历史文化底蕴深厚，考古相关企业数量遥遥领先，共158家，郑州、北京、洛阳以及南京等城市皆为古都，分别有考古企业62家、47家、42家和23家。</span></p><p><span style=\"font-size:12px;\">　　<strong>2020年新注册企业96家，今年前2月新增8家</strong></span></p><div class=\"img_wrapper\"><span style=\"font-size:12px;\"><img src=\"https://n.sinaimg.cn/finance/crawl/163/w550h413/20210322/88e5-kmrcukz8582766.png\" alt=\"\" /><span class=\"img_descr\"></span></span></div><p><span style=\"font-size:12px;\">　　随着国家对文物保护和考古发掘的重视，2011年以来的十年之间，考古企业注册量呈波动递增趋势。企查查数据显示，2011年共注册相关企业15家，2019年达到了十年来的最高点，共147家，同比增长47%，2020年注册量降至96家，同比减少35%。</span></p><div class=\"img_wrapper\"><span style=\"font-size:12px;\"><img src=\"https://n.sinaimg.cn/finance/crawl/162/w550h412/20210322/fab5-kmrcukz8582830.png\" alt=\"\" /><span class=\"img_descr\"></span></span></div><p><span style=\"font-size:12px;\">　　企查查数据显示，2021年前两个月共注册考古相关企业8家，同比减少38%。从月度来看，一二月份分别新注册4家。</span></p><div class=\"img_wrapper\"><span style=\"font-size:12px;\"><img src=\"https://n.sinaimg.cn/finance/crawl/273/w1070h803/20210322/788e-kmrcukz8582886.png\" alt=\"\" /><span class=\"img_descr\"></span></span></div><p><span style=\"font-size:12px;\">　　从注册资本来看，企查查数据显示，考古相关企业规模大多较小，注册资本在100万元以内的企业数量最多，占比达43%，注册资本在100万-500万元和500万-1000万元的分别占26%和12%。</span></p><p><span style=\"font-size:12px;\">　　三星堆遗址的发掘工作，体现了多学科、多机构合作的优势。与此同时，各类以考古为核心业务的企业与社会组织，也在大规模地进入到考古工作中去，以帮助我国考古事业更为有效地发展。</span></p>',0,'2021032215314967942.jpg','三星堆新发现背后：我国共1676家考古相关企业 豫陕两省最多',0,0,5),(3,'2021-03-22 15:35:48',0,'<div class=\"img_wrapper\"><span style=\"font-size:12px;\"><img src=\"https://n.sinaimg.cn/ent/transform/753/w630h923/20210322/f21c-kmrcukz8504598.jpg\" alt=\"王灿旧照\" data-link=\"\" /><span class=\"img_descr\">王灿旧照</span></span></div><div class=\"img_wrapper\"><span style=\"font-size:12px;\"><img src=\"https://n.sinaimg.cn/ent/transform/423/w630h593/20210322/c0d4-kmrcukz8544782.png\" alt=\"王灿回怼网友\" data-link=\"\" /></span></div><div class=\"img_wrapper\"><span class=\"img_descr\"><span style=\"font-size:12px;\">王灿回怼网友</span></span></div><p><span style=\"font-size:12px;\">　　新浪娱乐讯 3月22日，杜淳妻子王灿更新动态，声称自己从备孕到现在，所有的辛苦都是一种幸福。王灿晒出了旧照与现在照片进行前后对比，一张是2018年还未怀孕时的样子，画面中王灿身穿条纹背心，露出直角肩。齐刘海发型，清纯可爱。另一张是如今处于孕期的自己。照片显示拍摄于2021年，照片中王灿身穿宽松连衣裙，手抚圆润孕肚，面带微笑。</span></p><p><span style=\"font-size:12px;\">　　有网友却将关注点落在王灿笔挺的鼻子上面，直白地评论道：“鼻子做得不错”。王灿直接回应该网友的质疑，直言：“还真不是做的。”对于网友以为他和杜淳意外怀孕，王灿也表示：“备孕很辛苦呢“。</span></p>',0,'2021032215354831930.jpg','杜淳妻子晒旧照被质疑整容 遭王灿直言回怼',1,0,3),(4,'2021-03-22 15:42:11',0,'<p cms-style=\"font-L\"><span cms-style=\"font-L\" style=\"\"><span style=\"font-size:12px;\">新发现的5号坑中，三星堆考古发掘出土大量黄金制品，其中包括一张独特的金面具。与三星堆遗址1、2号坑中出土的金面具相比，此次最新出土的金面具，显得格外厚重且与众不同。</span></span></p><p cms-style=\"font-L\"><span style=\"font-size:12px;\">　　<span cms-style=\"font-L\" style=\"\">在金沙遗址博物馆中所保存的商周大金面具，是如今国内所发现的同时期最大的黄金面具。而此次发现的黄金面具，虽然是残件，目前所发现的面具只有半张，已足够令人惊喜。</span></span></p><div class=\"img_wrapper\"><span style=\"font-size:12px;\"><img id=\"6\" style=\"max-width: 640px;\" src=\"https://n.sinaimg.cn/spider2021321/107/w1024h683/20210321/4b9c-kmrcukz4879619.jpg\" alt=\"\" /><span class=\"img_descr\"></span></span></div><div class=\"img_wrapper\"><span style=\"font-size:12px;\"><img id=\"7\" style=\"max-width: 640px;\" src=\"https://n.sinaimg.cn/spider2021321/381/w760h421/20210321/83d0-kmrcukz5660878.jpg\" alt=\"\" /><span class=\"img_descr\"></span></span></div><div class=\"img_wrapper\"><span style=\"font-size:12px;\"><img id=\"8\" style=\"max-width: 640px;\" src=\"https://n.sinaimg.cn/spider2021321/80/w1080h600/20210321/6bea-kmrcukz5660910.jpg\" alt=\"\" /><span class=\"img_descr\"></span></span></div><p cms-style=\"strong-Bold font-L\"><span style=\"font-size:12px;\">　　<span cms-style=\"strong-Bold font-L\" style=\"\">“根据目前所发现半张面具推测，这件黄金面具完整的重量应该超过500g。”</span></span></p><p cms-style=\"font-L\"><span style=\"font-size:12px;\">　　<span cms-style=\"font-L\" style=\"\">三星堆遗址“祭祀区”考古发掘领队相关负责人说，这也意味着，如果能发现完整的黄金面具，那这不仅将是国内所发现的同时期最大的黄金面具，还将是国内所发现的同时期最重的金器。</span></span></p><div class=\"img_wrapper\"><span style=\"font-size:12px;\"><img id=\"9\" style=\"max-width: 640px;\" src=\"https://n.sinaimg.cn/spider2021321/107/w1024h683/20210321/b240-kmrcukz4879850.jpg\" alt=\"\" /><span class=\"img_descr\"></span></span></div><p cms-style=\"font-L\"><span style=\"font-size:12px;\">　　<span cms-style=\"font-L\" style=\"\">金面具正面</span></span></p><div class=\"img_wrapper\"><span style=\"font-size:12px;\"><img id=\"10\" style=\"max-width: 640px;\" src=\"https://n.sinaimg.cn/spider2021321/107/w1024h683/20210321/2aa7-kmrcukz4879100.jpg\" alt=\"\" /><span class=\"img_descr\"></span></span></div><p cms-style=\"font-L align-Center\"><span style=\"font-size:12px;\">　　<span cms-style=\"font-L align-Center\" style=\"\">金面具背面</span></span></p><p cms-style=\"font-L\"><span style=\"font-size:12px;\">　　<span cms-style=\"font-L\" style=\"\">据介绍，这件黄金面具，所发现的半张面具的宽度约23厘米，高度约28厘米，比完整的金沙大金面具还要大。同时，这件黄金面具厚度非常厚，不需要任何支撑，就可以独自立起来。</span></span></p><div class=\"img_wrapper\"><span style=\"font-size:12px;\"><img id=\"11\" style=\"max-width: 640px;\" src=\"https://n.sinaimg.cn/spider2021321/120/w1080h1440/20210321/8b5f-kmrcukz5660950.jpg\" alt=\"金面具大小（图源：三星堆博物馆）\" /></span></div><div class=\"img_wrapper\"><span style=\"font-size:12px;\"><span class=\"img_descr\">金面具大小（图源：三星堆博物馆）</span></span></div><p cms-style=\"font-L\"><span style=\"font-size:12px;\">　　<span cms-style=\"font-L\" style=\"\">虽只有半张，但方形面部、镂空大眼、三角鼻梁还有宽大的耳朵，这样的风格与此前三星堆所出土的黄金面罩和金沙大金面具风格十分相似。</span></span></p>',0,'2021032215421176828.jpg','黄金面具绝美！三星堆重大发现再惊天下',0,0,5),(5,'2021-03-22 15:42:53',0,'<div class=\"img_wrapper\"><span style=\"font-size:12px;\"><img src=\"https://n.sinaimg.cn/sports/transform/283/w650h433/20210322/a1da-kmrcukz7160436.jpg\" alt=\"\" data-link=\"\" /><span class=\"img_descr\"></span></span></div><p><span style=\"font-size:12px;\">　　北京时间3月22日，篮网在主场以113-106击退奇才。</span></p><p><span style=\"font-size:12px;\">　　篮网（29-14）比较轻松地过关，凯里-欧文28分、7个篮板和6次助攻，詹姆斯-哈登26分8次助攻，德安德烈-乔丹12分5个篮板，乔-哈里斯10分，杰夫-格林3分。替补出场的尼古拉斯-克拉克斯顿16分，布雷克-格里芬首度出战，只打15分钟，得2分2个篮板。</span></p><p><span style=\"font-size:12px;\">　　奇才（15-26）三人上了20分，拉塞尔-威斯布鲁克29分、13个篮板和13次助攻，阿莱克斯-林恩20分9个篮板，八村垒20分10个篮板，布拉德利-比尔17分，加里森-马修斯6分。</span></p>',0,'2021032215425315173.jpg','格里芬首秀欧文砍28分 威少三双奇才不敌篮网',0,0,4),(6,'2021-03-22 15:43:42',0,'<p cms-style=\"font-L\"><span style=\"font-size:12px;\">　新华社北京3月22日电 3月22日，国家主席习近平同科威特埃米尔纳瓦夫互致贺电，庆祝两国建交50周年。</span></p><p cms-style=\"font-L\"><span style=\"font-size:12px;\">　　习近平在贺电中指出，中科建交半个世纪以来，两国传统友谊历久弥坚。近年来，两国建立战略伙伴关系，政治互信日益深化，各领域合作成果丰硕，在涉及彼此核心利益和重大关切问题上相互理解、相互支持，在国际和地区事务中密切配合。新冠肺炎疫情发生后，双方同舟共济，共同抗击疫情，体现了中科关系的高水平。我高度重视中科关系发展，愿同纳瓦夫埃米尔一道努力，以两国建交50周年为契机，弘扬传统友好，在共建“一带一路”框架内深化各领域合作，造福两国和两国人民。</span></p><p cms-style=\"font-L\"><span style=\"font-size:12px;\">　　纳瓦夫在贺电中表示，科中两国关系牢固，并不断发展、深化。双方在战略伙伴关系框架内就多个重大项目开展合作，在国际和地区问题上也保持沟通协调，共同维护世界和平与安全。面对新冠肺炎疫情，两国开展了积极协调和密切合作。我期待进一步加强双边关系，提升和拓展各领域合作。</span></p><p cms-style=\"font-L\"><span style=\"font-size:12px;\">　　同日，国务院总理李克强同科威特首相萨巴赫互致贺电。李克强在贺电中表示，中科建交50年来，双边关系发展顺利，政治互信日益巩固，共建“一带一路”合作稳步推进，能源、基础设施、金融、人文等领域合作富有成果，两国人民的相互了解和友谊不断加深。中方愿同科方共同推动中科战略伙伴关系取得更大发展。</span></p><p cms-style=\"font-L\"><span style=\"font-size:12px;\">　　萨巴赫在贺电中表示，科中两国友好关系牢固、密切，合作成果丰硕。科方高度重视科中友好关系，希望继续同中方一道，全方位提升双方战略关系水平，实现友好的两国和两国人民的期待。</span></p>',0,'2021032215434219058.jpg','习近平同科威特埃米尔纳瓦夫就中科建交50周年互致贺电',3,0,1),(7,'2021-03-22 15:44:40',1,'<p cms-style=\"font-L\"><span cms-style=\"font-L\" style=\"\"><span style=\"font-size:12px;\">&nbsp; &nbsp; &nbsp;国务院联防联控机制21日召开发布会介绍，截至3月20日24时，全国累计报告接种7495.6万剂次，部分地区已经开始为60岁以上身体条件比较好的老人开展接种新冠疫苗。在条件成熟后，将大规模开展60岁以上老年人群的疫苗接种。</span></span></p><p cms-style=\"font-L\"><span style=\"font-size:12px;\">　　<span cms-style=\"font-L\" style=\"\">我国的新冠疫苗接种工作正有序推进，然而一些民众仍对是否打疫苗存在疑虑。对此，中国工程院院士钟南山、中国疾病预防控制中心主任高福、复旦大学附属华山医院感染科主任张文宏接连公开表示，</span><span cms-style=\"font-L strong-Bold\" style=\"\">接种疫苗十分必要，不能再犹豫。</span></span></p><p cms-style=\"strong-Bold font-L\"><span style=\"font-size:12px;\">　　<span cms-style=\"font-L strong-Bold\" style=\"\">最快今年底明年初</span></span></p><p cms-style=\"strong-Bold font-L\"><span style=\"font-size:12px;\">　　<span cms-style=\"font-L strong-Bold\" style=\"\">国内基本实现群体免疫</span></span></p><p cms-style=\"font-L\"><span style=\"font-size:12px;\">　　我国要实现群体免疫，需要多大比例、多少人口接种疫苗？</span></p><p cms-style=\"font-L\"><span style=\"font-size:12px;\">　　“群体免疫不能通过让大量的人患病来实现，必须要以科学为基准，通过疫苗接种来达成这样的目标。全球的群体免疫需要至少2~3年的时间，甚至更长。”钟南山院士曾在“快速复苏的正轨：中美新冠疫情防控与治疗合作”论坛上介绍，据他了解，<span cms-style=\"font-L strong-Bold\" style=\"\">今年6月，中国新冠疫苗接种率计划有望达到40%。</span></span></p><p cms-style=\"font-L\"><span style=\"font-size:12px;\">　　中国疾病预防控制中心主任高福在接受央视新闻采访时回应，这取决于病毒本身的特性，不同的病毒是不一样。比如麻疹，不到90%不行，甚至要达到95%以上；根据新冠病毒的基本传播指数，<span cms-style=\"font-L strong-Bold\" style=\"\">大家比较认可的推测是70%-80%</span><span cms-style=\"font-L\" style=\"\">。希望到2022年年初、甚至今年年底，中国能达到70%-80%的新冠疫苗接种率，基本实现群体免疫。</span></span></p><p cms-style=\"font-L\"><span style=\"font-size:12px;\">　　<span cms-style=\"font-L\" style=\"\">不过，张文宏认为，在中国完成接种70%的比例是不够的，具体多高目前很难预测，但应该是越多越好。</span><span cms-style=\"font-L strong-Bold\" style=\"\">“接近90%是比较重要的接种率，80%是最最起码的要求。”</span></span></p><p cms-style=\"strong-Bold font-L\"><span style=\"font-size:12px;\">　　<span cms-style=\"font-L strong-Bold\" style=\"\">疫苗是消除新冠的终极武器</span></span></p><p cms-style=\"font-L\"><span style=\"font-size:12px;\">　　<span cms-style=\"font-L\" style=\"\">然而，一些民众仍抱着“再等一等”的想法，观望、犹豫。对此，高福表示，疫苗是我们最后消除消灭新冠的终极产品，大家一定要对疫苗有信心。“过去的经验告诉我们，我们靠疫苗消灭了天花，消除了小儿麻痹，也是凭借疫苗，使我国的乙肝由原来百分之十几降到现在5岁以下的孩子感染率为千分之三，所以大家一定不要再‘疫苗犹豫’。”</span></span></p><div class=\"img_wrapper\"><span style=\"font-size:12px;\"><img src=\"https://n.sinaimg.cn/sinakd2021322s/172/w640h332/20210322/a696-kmrcukz8404601.jpg\" alt=\"\" /></span></div><p cms-style=\"font-L\"><span style=\"font-size:12px;\">　　高福还强调，这是人类第一次接种新型冠状病毒疫苗，没有科学证据说明哪种疫苗最好，各国根据实际情况来确定先启动哪种疫苗的研发，但最终可能殊途同归。</span></p><p cms-style=\"font-L\"><span style=\"font-size:12px;\">　　此前，张文宏也犀利直言：“<span cms-style=\"font-L strong-Bold\" style=\"\">不要现在盼着疫苗来，真的疫苗来了又不敢打。</span><span cms-style=\"font-L\" style=\"\">在这一年内，疫苗是要打的。反正我打了，大家都看到了，而且我认为非常有必要打。</span><span cms-style=\"font-L strong-Bold\" style=\"\">如果不打，世界重新开放的时候，我们是没有免疫力的。</span><span cms-style=\"font-L\" style=\"\">这个问题非常清楚——疫苗要打。”</span></span></p><p cms-style=\"strong-Bold font-L\"><span style=\"font-size:12px;\">　　<span cms-style=\"font-L strong-Bold\" style=\"\">疫苗接种不到位</span></span></p><p cms-style=\"strong-Bold font-L\"><span style=\"font-size:12px;\">　　<span cms-style=\"font-L strong-Bold\" style=\"\">疫情或将再次蔓延</span></span></p><p cms-style=\"font-L\"><span style=\"font-size:12px;\">　　<span cms-style=\"font-L\" style=\"\">3月20日，张文宏在长三角新经济年会上发表演讲时称，</span><span cms-style=\"font-L strong-Bold\" style=\"\">新冠感染后大量的无症状病例使得全球必须要采取极为积极的疫苗接种策略</span><span cms-style=\"font-L\" style=\"\">，以遏制新冠病毒的传播。</span></span></p><div class=\"img_wrapper\"><span style=\"font-size:12px;\"><img src=\"https://n.sinaimg.cn/sinakd2021322s/237/w640h397/20210322/ca80-kmrcukz7650590.jpg\" alt=\"\" /></span></div><p cms-style=\"font-L\"><span style=\"font-size:12px;\">　　<span cms-style=\"font-L\" style=\"\">张文宏先以武汉的数据举例称，武汉最新的新冠抗体阳性率6.9%，其中82%的人系无症状感染者，未曾出现过任何新冠相关的症状。“这意味着感染率是非常高的，有些人症状是非常非常轻，但是即便如此，抗体阳性率只有6.9%，</span><span cms-style=\"font-L strong-Bold\" style=\"\">如果不进行疫苗的接种，我们仍然有很大的感染的风险。</span><span cms-style=\"font-L\" style=\"\">”</span></span></p><p cms-style=\"font-L\"><span style=\"font-size:12px;\">　　<span cms-style=\"font-L\" style=\"\">张文宏接着举例说，随着世界各国的政策开放，有些国家的发病率最近又开始上升，但以色列因为疫苗接种进程很快，现在有60%到70%的人已经完成两针疫苗接种，现在的新发病例每天只有几百例。相反，</span><span cms-style=\"font-L strong-Bold\" style=\"\">南美由于疫苗接种普及不到位，又出现了发病率上升的趋势。</span></span></p><p cms-style=\"font-L\"><span style=\"font-size:12px;\">　　<span cms-style=\"font-L\" style=\"\">张文宏警示：“</span><span cms-style=\"font-L strong-Bold\" style=\"\">我们中国如果疫苗接种不到位，将来有可能会承受疾病的再次蔓延</span><span cms-style=\"font-L\" style=\"\">；如果我们中国的疫苗接种速度不够快，那么将来我们的人群感染率就会提高。”</span></span></p>',1,'2021032215444046558.jpg','张文宏用两个例子警示:疫苗接种不到位 或有严重后果',46,1,2),(8,'2021-03-22 16:55:39',1,'<p><span style=\"font-size:16px;\">牛年以来，市场持续震荡，但碳中和板块逆势大涨，持续受到追捧，2021年以来A股市场首只10倍股或从这一板块诞生。</span></p><p><span style=\"font-size:16px;\">　　年内首只10倍股将诞生？来自这一热门板块</span></p><p><span style=\"font-size:16px;\">　　行情数据显示，A股上市公司<span id=\"stock_sz003035\"><a href=\"https://finance.sina.com.cn/realstock/company/sz003035/nc.shtml\" class=\"keyword\" target=\"_blank\" data-sudaclick=\"content_marketkeywords_p\">南网能源</a></span><span id=\"quote_sz003035\">(<span style=\"color:red;\">13.110</span>, <span style=\"color:red;\">1.19</span>, <span style=\"color:red;\">9.98%</span>)</span>（003035.SZ）今天上午再次冲击涨停，报13.11元。该股最近一段时间涨势惊人，实现5天4板，3月份以来股价涨幅超过100%。</span></p><p><span style=\"font-size:16px;\">　　南网能源今年1月份上市，发行价为1.40元，今天的最高价已是其发行价的9.36倍，如果下一交易日继续涨停，南网能源的股价将是其发行价的10倍以上，这意味着，南网能源很有可能成为2021年以来A股市场首只10倍股！</span></p><div class=\"img_wrapper\"><span style=\"font-size:16px;\"><img id=\"0\" src=\"https://n.sinaimg.cn/spider2021322/33/w558h275/20210322/16df-kmrcukz8135421.png\" alt=\"\" /><span class=\"img_descr\"></span></span></div><p><span style=\"font-size:16px;\">　　南网能源能如此强势，除了其发行价相对较低外，还与其目前处于市场热点的风口有一定关系。</span></p><p><span style=\"font-size:16px;\">　　南网能源主要从事节能服务，为客户能源使用提供诊断、设计、改造、综合能源项目投资及运营维护等一站式综合节能服务。公司通过整合节能环保技术，利用高效节能环保设备，转变客户用能来源、用能方式，在满足客户对各类能源（电、热、冷、蒸汽、压缩气体等）需求的同时，降低客户用能投资风险，提升客户能源使用效率、减少能源费用和碳排放。这一业务特点与当前市场上火热的碳中和概念非常契合。</span></p><p><span style=\"font-size:16px;\">　　在A股市场上，除了南网能源外，整个碳中和概念板块近期也涨势凌厉，明显强于同期大盘。</span></p><p><span style=\"font-size:16px;\">　　行情数据显示，Wind碳中和指数今年2月上旬尚一度只有794.25点，但近期持续猛涨，今天盘中离1100点已经不远，短短一个多月的时间涨幅超过30%，同期上证指数、深证成指等大盘指数却处于连续调整状态，两者形成鲜明对比。</span></p><div class=\"img_wrapper\"><span style=\"font-size:16px;\"><img id=\"1\" src=\"https://n.sinaimg.cn/spider2021322/92/w558h334/20210322/74e7-kmrcukz8135424.png\" alt=\"\" /><span class=\"img_descr\"></span></span></div><p><span style=\"font-size:16px;\">　　实际上，碳中和为近年全球共同关注的话题。</span></p><p><span style=\"font-size:16px;\">　　百科资料显示，碳中和是指国家、企业、产品、活动或个人在一定时间内直接或间接产生的二氧化碳或温室气体排放总量，通过植树造林、节能减排等形式，以抵消自身产生的二氧化碳或温室气体排放量，实现正负抵消，达到相对“零排放”。</span></p><p><span style=\"font-size:16px;\">　　消息面上，为贯彻落实党中央、国务院决策部署，切实做好碳达峰、碳中和顶层设计，3月18日下午，国家发改委环资司副司长赵鹏高主持召开专家座谈会，听取有关专家对相关工作的意见和建议。</span></p><p><span style=\"font-size:16px;\">　　与会专家一致认为，我国力争2030年前实现碳达峰，2060年前实现碳中和，是党中央经过深思熟虑作出的重大战略决策，事关中华民族永续发展和构建人类命运共同体。我国实现碳达峰、碳中和的时间紧、任务重，迫切需要加强顶层设计和统筹谋划。与会专家建议加快出台碳达峰、碳中和顶层设计政策文件，进一步提高各方认识，突出碳达峰、碳中和的工作重点，科学设定各阶段目标，明确基本原则、工作方向和主要任务，压实各行业、各地方主体责任，推动形成“1+N”政策体系，确保如期实现碳达峰、碳中和目标。下一步，国家发改委环资司将进一步深化论证研究，加快推进碳达峰、碳中和顶层设计相关工作。</span></p><p><span style=\"font-size:16px;\">　　3月20日，高瓴创始人兼CEO张磊表示，中国实现碳中和可能需要数百万亿级的投资和持续数十年的努力。张磊认为，在电力、交通、工业、新材料、建筑、农业、负碳排放以及信息通信与数字化等领域孕育着重要投资机遇。张磊提到，在新能源技术、材料、工艺等“绿色新基建”领域，高瓴按照“碳中和”技术路线图，深入布局了光伏、新能源汽车和芯片等产业链上下游。</span></p><p><span style=\"font-size:16px;\">　　理性看待碳中和概念大火</span></p><p><span style=\"font-size:16px;\">　　A股市场向来不乏概念炒作机会，不少资金借助相关题材，进行强力炒作。散户跟风，但一窝蜂跟风炒作的概念股，最终成一地鸡毛的不在少数，相关概念股炒作是否经得起考验仍需实际业绩支撑。</span></p><p><span style=\"font-size:16px;\">　　如A股历史上区块链相关题材曾经历多次爆炒。2015年，相关概念股的炒作达到历史巅峰，但相关个股此后数年连续下跌，目前总体股价水平离当年仍有不小差距。</span></p><p><span style=\"font-size:16px;\">　　行情数据显示，Wind区块链指数2015年曾经超过9000点，该指数目前不到3000点，时隔5年已跌去超过2/3。</span></p><div class=\"img_wrapper\"><span style=\"font-size:16px;\"><img id=\"2\" src=\"https://n.sinaimg.cn/spider2021322/40/w558h282/20210322/37f3-kmrcukz8135707.png\" alt=\"\" /><span class=\"img_descr\"></span></span></div><p><span style=\"font-size:16px;\">　　<span id=\"stock_sz000776\"><a href=\"https://finance.sina.com.cn/realstock/company/sz000776/nc.shtml\" class=\"keyword\" target=\"_blank\" data-sudaclick=\"content_marketkeywords_p\">广发证券</a></span><span id=\"quote_sz000776\">(<span style=\"color:red;\">15.630</span>, <span style=\"color:red;\">0.22</span>, <span style=\"color:red;\">1.43%</span>)</span>近日的研究观点指出， 2016年以来的“供给侧改革”以及供给收缩常态化政策导致企业的产能供给低位，产能利用率持续高位，企业长期处于“供需紧平衡”状态。今年疫苗接种落地全球经济修复，部分产能利用率高位&amp;产能供给存在“滞后期”的上游资源行业“供需缺口”扩张带来涨价行情。该机构在此前的研究观点中指出，除了上游资源涨价行情外，“供需缺口”潜在扩张的中游制造/可选消费等行业也具备涨价潜力。其中，“碳中和”供给收缩预期将进一步强化相关顺周期细分行业的涨价预期，包括煤炭、钢铁、水泥和玻璃等。</span></p><p><span style=\"font-size:16px;\">　　在碳中和这一话题上，<span id=\"stock_sh601995\"><a href=\"https://finance.sina.com.cn/realstock/company/sh601995/nc.shtml\" class=\"keyword\" target=\"_blank\" data-sudaclick=\"content_marketkeywords_p\">中金公司</a></span><span id=\"quote_sh601995\">(<span style=\"color:red;\">50.460</span>, <span style=\"color:red;\">1.76</span>, <span style=\"color:red;\">3.61%</span>)</span>彭文生、谢超、李瑾近日发布的研报认为，对于碳中和，同一碳排放，不宜统一碳定价。</span></p><p><span style=\"font-size:16px;\">　　中金公司的上述观点认为，适合纳入碳市场的主要是电力、钢铁两个行业，交运、化工、建材行业可能更适合碳税的碳定价机制；统一碳价的思路并不可取，应采取差别碳价；相比于理论上的碳的社会成本折现，绿色溢价下的平价碳成本可能更适合作为现实中制定碳价的参考依据。</span></p><p><span style=\"font-size:16px;\">　　中金公司的研究观点指出，碳定价也只是降低绿色溢价的一个方式，而非全部答案。该机构认为，从规范人类经济活动的角度，可以借鉴环保政策的类型划分法，将碳中和政策工具划分为命令型、价格型以及宣传型政策三类。所谓价格型政策即是前面讨论的碳定价，也是目前被认为最重要的碳中和政策。命令型政策，主要是指依赖于政府强制性行政命令或者法律法规推行的政策，主要内容既包括制度化的制定、执行排放标准，也包括对排放行为的日常性行政干预，常见的关停限产、汽车单双号限行也都属于命令型政策。宣传型政策，则是通过信息公开、舆论宣传等方式，来影响人类的排放行为，通常不具有强制性，也没有物质激励，更多的通过提升人类的减排意识来推动碳中和。</span></p><p><span style=\"font-size:16px;\">　　<span id=\"stock_sz002673\" style=\"\"><a href=\"https://finance.sina.com.cn/realstock/company/sz002673/nc.shtml\" class=\"keyword\" target=\"_blank\" data-sudaclick=\"content_marketkeywords_p\">西部证券</a></span><span id=\"quote_sz002673\" style=\"\">(<span style=\"color:red;\">8.850</span>, <span style=\"color:red;\">0.15</span>, <span style=\"color:red;\">1.72%</span>)</span>的研究观点认为，“碳中和”在供需两方面均对中上游相关行业产生深远影响，供给侧改革限制产能投放而“碳中和”相关品种需求则持续升温。叠加全球复工复产热度不减，工业品需求引发的通胀交易或进入“白 热化”。具体景气度研判如下：（1）上游景气度排序，化工/煤炭/有色/ 钢铁/交运；（2）中游景气度排序，工程器械&gt;电气设备/建材；（3）下 游景气度排序，新能源车/造纸/免税&gt;影视传媒/乘用车/航空&gt;农林牧渔；（4）TMT景气度排序：半导体&gt;面板&gt;智能手机；（5）金融景气度排序：券商/银行。</span></p>',1,'2021032215461668635.png','“碳中和”热得烫手 后市如何走？机构火线解读',58,1,6);
/*!40000 ALTER TABLE `t_article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_article_comment`
--

DROP TABLE IF EXISTS `t_article_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_article_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `addDate` varchar(255) DEFAULT NULL,
  `comment` varchar(5000) DEFAULT NULL,
  `userread` varchar(255) DEFAULT NULL,
  `articleId` int(11) DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  `rcount` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FKade7gkbfjsdijckul8iy58vq` (`articleId`) USING BTREE,
  KEY `FK3bwgp495jya6leqk6kgj327hi` (`userId`) USING BTREE,
  CONSTRAINT `FK3bwgp495jya6leqk6kgj327hi` FOREIGN KEY (`userId`) REFERENCES `t_user` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FKade7gkbfjsdijckul8iy58vq` FOREIGN KEY (`articleId`) REFERENCES `t_article` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_article_comment`
--

LOCK TABLES `t_article_comment` WRITE;
/*!40000 ALTER TABLE `t_article_comment` DISABLE KEYS */;
INSERT INTO `t_article_comment` VALUES (1,'2021-03-22','西部证券(8.850, 0.15, 1.72%)的研究观点认为，“碳中和”在供需两方面均对中上游相关行业产生深远影响，供给侧改革限制产能投放而“碳中和”相关品种需求则持续升温。叠加全球复工复产热度不减，工业品需求引发的通胀交易或进入“白 热化”。具体景气度研判如下：（1）上游景气度排序，化工/煤炭/有色/ 钢铁/交运；（2）中游景气度排序，',NULL,8,1,0),(2,'2021-03-22','西部证券(8.850, 0.15, 1.72%)的研究观点认为，“碳中和”在供需两方面均对中上游相关行业产生深远影响，供给侧改革限制产能投放而“碳中和”相关品种需求则持续升温。叠加全球复工复产热度不减，工业品需求引发的通胀交易或进入“白 热化”。具体景气度研判如下：（1）上游景气度排序，化工/煤炭/有色/ 钢铁/交运；（2）中游景气度排序，',NULL,8,1,2),(3,'2021-03-22','　　张文宏警示：“我们中国如果疫苗接种不到位，将来有可能会承受疾病的再次蔓延；如果我们中国的疫苗接种速度不够快，那么将来我们的人群感染率就会提高。”',NULL,7,1,2);
/*!40000 ALTER TABLE `t_article_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_article_comment_reply`
--

DROP TABLE IF EXISTS `t_article_comment_reply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_article_comment_reply` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `addDate` varchar(255) DEFAULT NULL,
  `content` varchar(5000) DEFAULT NULL,
  `articleCommentId` int(11) DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FKc8822026dio1cmw4e5glks2oj` (`articleCommentId`) USING BTREE,
  KEY `FKfq176gkm7o3ax0d87d63jtajs` (`userId`) USING BTREE,
  CONSTRAINT `FKfq176gkm7o3ax0d87d63jtajs` FOREIGN KEY (`userId`) REFERENCES `t_user` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FKc8822026dio1cmw4e5glks2oj` FOREIGN KEY (`articleCommentId`) REFERENCES `t_article_comment` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_article_comment_reply`
--

LOCK TABLES `t_article_comment_reply` WRITE;
/*!40000 ALTER TABLE `t_article_comment_reply` DISABLE KEYS */;
INSERT INTO `t_article_comment_reply` VALUES (1,'2021-04-23','123',2,1),(2,'2021-04-23','dddddddddddddddd',2,1),(3,'2021-04-23','的发射点发射点发生',1,1);
/*!40000 ALTER TABLE `t_article_comment_reply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_cai`
--

DROP TABLE IF EXISTS `t_cai`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_cai` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `articleId` int(11) DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK7u0af9pxkf83gca87px6tw90n` (`articleId`) USING BTREE,
  KEY `FKfvix638clsh46tuxsfhdo90kv` (`userId`) USING BTREE,
  CONSTRAINT `FK7u0af9pxkf83gca87px6tw90n` FOREIGN KEY (`articleId`) REFERENCES `t_article` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FKfvix638clsh46tuxsfhdo90kv` FOREIGN KEY (`userId`) REFERENCES `t_user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_cai`
--

LOCK TABLES `t_cai` WRITE;
/*!40000 ALTER TABLE `t_cai` DISABLE KEYS */;
INSERT INTO `t_cai` VALUES (1,8,1),(2,7,1);
/*!40000 ALTER TABLE `t_cai` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_database_file`
--

DROP TABLE IF EXISTS `t_database_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_database_file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `addDate` varchar(255) DEFAULT NULL,
  `filePath` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_database_file`
--

LOCK TABLES `t_database_file` WRITE;
/*!40000 ALTER TABLE `t_database_file` DISABLE KEYS */;
INSERT INTO `t_database_file` VALUES (1,'2021-03-22 16:52:20','20210322165220.sql'),(2,'2021-03-22 16:54:53','20210322165453.sql'),(5,'2021-04-26 23:39:58','20210426233958.sql'),(6,'2021-04-26 23:41:18','20210426234118.sql');
/*!40000 ALTER TABLE `t_database_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_link`
--

DROP TABLE IF EXISTS `t_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_link` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_link`
--

LOCK TABLES `t_link` WRITE;
/*!40000 ALTER TABLE `t_link` DISABLE KEYS */;
INSERT INTO `t_link` VALUES (1,'凤凰资讯','凤凰资讯凤凰资讯凤凰资讯凤凰资讯凤凰资讯凤凰资讯凤凰资讯凤凰资讯凤凰资讯','http://news.ifeng.com/'),(2,'腾讯新闻','腾讯新闻腾讯新闻腾讯新闻腾讯新闻腾讯新闻腾讯新闻腾讯新闻腾讯新闻','http://news.qq.com/'),(3,'人民网','人民网人民网人民网人民网人民网人民网人民网人民网人民网','http://www.people.com.cn/');
/*!40000 ALTER TABLE `t_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_news`
--

DROP TABLE IF EXISTS `t_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `addDate` varchar(255) DEFAULT NULL,
  `content` varchar(5000) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_news`
--

LOCK TABLES `t_news` WRITE;
/*!40000 ALTER TABLE `t_news` DISABLE KEYS */;
INSERT INTO `t_news` VALUES (1,'2021-03-22','我常写真人真事，真人真事文章不一定都是新闻，新闻和真人真事文学作品有很大的区别，很大的区别说明这是不同的领域，不同的领域讲究术业有专攻，术业有专攻的道理让我从不写新闻，写新闻的知识用于评价文学作品的通常是新闻媒体记者，记者们常会把真人真事文学作品当成不合格的新闻。<br /><div class=\"contheight\"></div>&nbsp;<img alt=\"配图来源于网络，图文无关\" style=\"width:600px;\" src=\"https://imagepphcloud.thepaper.cn/pph/image/121/495/451.jpg\" /><p class=\"image_desc\">配图来源于网络，图文无关</p><br /><div class=\"contheight\"></div><strong>“笔杆子”们居然分不清新闻和文学？</strong><br /><div class=\"contheight\"></div>新闻与文学怎可混为一谈？两者是有区别的。<br /><div class=\"contheight\"></div>这问题的根源，与现在的自媒体风气有关。现在大多数自媒体作者都确实是在模仿媒体新闻报道里的语气，他们所发的文章也大多数都是在复述官方媒体已报道的消息，语气上半遮掩地充当着媒体记者，况且还模仿不到位，那就怪不得总遭真正的媒体记者鄙视了。<br /><div class=\"contheight\"></div>&nbsp;<img alt=\"配图来源于网络，图文无关\" style=\"width:600px;\" src=\"https://imagepphcloud.thepaper.cn/pph/image/121/495/452.jpg\" /><p class=\"image_desc\">配图来源于网络，图文无关</p><br /><div class=\"contheight\"></div>但不可一概而论，除了那些只为写作而写作，胡乱跟风瞎模仿的自媒体作者之外，也有极少数认真创作的自媒体作者。<br /><div class=\"contheight\"></div>例如我现在写的真人真事文章，我不仅没有去模仿官方媒体的新闻报道，而且我还在刻意避免与他们相似。<br /><div class=\"contheight\"></div>没错，我就是专门用文学体裁写真人真事的自媒体作者。谁说真人真事文章就一定得用新闻体写？我用文学体裁写真事，就总不会和媒体新闻相似了吧？<br /><div class=\"contheight\"></div>我也没有去复述官方媒体已报道的消息当复读机，我的真人真事文章内容都是自己亲自去找当事人采编来的。<br /><div class=\"contheight\"></div>但却总有人跟我说，我写的某篇文章不符合新闻标准。但请看清楚了，我写的是新闻吗？除了新闻，可认得文学？<br /><div class=\"contheight\"></div>&nbsp;<img alt=\"本文作者小侯的头像\" style=\"width:600px;\" src=\"https://imagepphcloud.thepaper.cn/pph/image/121/495/458.png\" /><p class=\"image_desc\">本文作者小侯的头像</p>&nbsp;<img alt=\"配图来源于网络，图文无关\" style=\"width:600px;\" src=\"https://imagepphcloud.thepaper.cn/pph/image/121/495/461.jpg\" />','新闻和文学是有区别的');
/*!40000 ALTER TABLE `t_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_user`
--

DROP TABLE IF EXISTS `t_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `photo` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `userID` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK3o3ax8ghmdoycox06c9o51xxs` (`userID`) USING BTREE,
  CONSTRAINT `FK3o3ax8ghmdoycox06c9o51xxs` FOREIGN KEY (`userID`) REFERENCES `t_userinfo` (`userID`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_user`
--

LOCK TABLES `t_user` WRITE;
/*!40000 ALTER TABLE `t_user` DISABLE KEYS */;
INSERT INTO `t_user` VALUES (1,'2021032216561779313.jpg',NULL,2);
/*!40000 ALTER TABLE `t_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_user_log`
--

DROP TABLE IF EXISTS `t_user_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_user_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `addDate` varchar(255) DEFAULT NULL,
  `articleId` int(11) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_user_log`
--

LOCK TABLES `t_user_log` WRITE;
/*!40000 ALTER TABLE `t_user_log` DISABLE KEYS */;
INSERT INTO `t_user_log` VALUES (1,'2021-04-22',8,'浏览'),(2,'2021-04-25',8,'浏览'),(3,'2021-04-22',8,'浏览'),(4,'2021-04-25',8,'浏览'),(5,'2021-04-22',8,'浏览'),(6,'2021-04-25',8,'浏览'),(7,'2021-04-22',8,'浏览'),(8,'2021-04-25',8,'浏览'),(9,'2021-04-25',8,'浏览'),(10,'2021-04-20',8,'浏览'),(11,'2021-04-21',8,'浏览'),(12,'2021-04-23',8,'浏览'),(13,'2021-04-21',8,'浏览'),(14,'2021-04-23',8,'浏览'),(15,'2021-04-20',8,'浏览'),(16,'2021-04-21',8,'浏览'),(17,'2021-04-20',8,'浏览'),(18,'2021-04-23',8,'浏览'),(19,'2021-04-20',8,'浏览');
/*!40000 ALTER TABLE `t_user_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_userfav`
--

DROP TABLE IF EXISTS `t_userfav`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_userfav` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `articleId` int(11) DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FKlxev72kgxpcsmha31tpot8ccj` (`articleId`) USING BTREE,
  KEY `FKmlhy7wvvmu2yc2y0rph40m453` (`userId`) USING BTREE,
  CONSTRAINT `FKlxev72kgxpcsmha31tpot8ccj` FOREIGN KEY (`articleId`) REFERENCES `t_article` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FKmlhy7wvvmu2yc2y0rph40m453` FOREIGN KEY (`userId`) REFERENCES `t_user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_userfav`
--

LOCK TABLES `t_userfav` WRITE;
/*!40000 ALTER TABLE `t_userfav` DISABLE KEYS */;
INSERT INTO `t_userfav` VALUES (1,8,1),(2,7,1);
/*!40000 ALTER TABLE `t_userfav` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_userinfo`
--

DROP TABLE IF EXISTS `t_userinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_userinfo` (
  `userID` int(11) NOT NULL AUTO_INCREMENT,
  `uname` varchar(20) NOT NULL,
  `userAddress` varchar(100) DEFAULT NULL,
  `userBirth` varchar(10) DEFAULT NULL,
  `userEmail` varchar(50) DEFAULT NULL,
  `userGender` int(11) NOT NULL,
  `userName` varchar(20) NOT NULL,
  `userPassword` varchar(150) NOT NULL,
  `userPhone` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`userID`) USING BTREE,
  UNIQUE KEY `UK_gtw1ky2fmh09tsu11w8tlpkk0` (`uname`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_userinfo`
--

LOCK TABLES `t_userinfo` WRITE;
/*!40000 ALTER TABLE `t_userinfo` DISABLE KEYS */;
INSERT INTO `t_userinfo` VALUES (1,'admin',NULL,NULL,NULL,1,'管理员','E10ADC3949BA59ABBE56E057F20F883E',NULL),(2,'user1','','','',1,'王宝强','E10ADC3949BA59ABBE56E057F20F883E','17897987987');
/*!40000 ALTER TABLE `t_userinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_zan`
--

DROP TABLE IF EXISTS `t_zan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_zan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `articleId` int(11) DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK4duwoavntne26e4lhk10w5mtu` (`articleId`) USING BTREE,
  KEY `FKhpkm4lpihg5b5mfi35x5spkd7` (`userId`) USING BTREE,
  CONSTRAINT `FK4duwoavntne26e4lhk10w5mtu` FOREIGN KEY (`articleId`) REFERENCES `t_article` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FKhpkm4lpihg5b5mfi35x5spkd7` FOREIGN KEY (`userId`) REFERENCES `t_user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_zan`
--

LOCK TABLES `t_zan` WRITE;
/*!40000 ALTER TABLE `t_zan` DISABLE KEYS */;
INSERT INTO `t_zan` VALUES (1,8,1),(2,7,1);
/*!40000 ALTER TABLE `t_zan` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-04-26 23:41:18
