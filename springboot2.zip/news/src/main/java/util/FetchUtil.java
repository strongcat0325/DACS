package util;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpStatus;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import cn.boot.entity.Weather;

public class FetchUtil {
	protected static Logger log = Logger.getLogger(FetchUtil.class);

	public static void main(String[] args) {
		List<Weather> weather = getWeather("杭州");
		for (Weather weather2 : weather) {
			System.out.println(weather2);
		}
	}

	public static List<Weather> getWeatherHistory(String city, String sdate) {

		List<Weather> list = new ArrayList<Weather>();
		try {
			String s = getHtmlTextDocument(
					"http://api.k780.com:88/?app=weather.history&appkey=24557&sign=1b9830fa189d1494dd0355b61ee69f63&format=json&date=" + sdate
							+ "&weaid=" + city,
					"UTF-8");
			System.out.println(s);
			JSONObject root = JSONObject.parseObject(s);
			JSONArray ary = root.getJSONArray("result");
			for (int i = 0; i < ary.size(); i++) {
				JSONObject obj = ary.getJSONObject(i);

				String hign = obj.getString("temp");
				int whign = Integer.valueOf(hign);

				String low = obj.getString("temp");
				int wlow = Integer.valueOf(low);

				Weather w = new Weather();
				//w.setAddDate(cdate);
				w.setAddDate(obj.getString("uptime"));
				w.setCity(city);
				w.setFengli(obj.getString("winp"));
				w.setFengxiang(obj.getString("wind"));
				w.setWtype(obj.getString("weather"));
				w.setWhign(whign);
				w.setWlow(wlow);
				w.setIcon1(obj.getString("weather_icon"));
				//w.setIcon2(obj.getString("weather_icon1"));
				list.add(w);

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	public static List<String[]> getSuggest(String city) {

		List<String[]> list = new ArrayList<>();
		try {
			String s = getHtmlTextDocument(
					"http://api.k780.com:88/?app=weather.lifeindex&appkey=24557&sign=1b9830fa189d1494dd0355b61ee69f63&format=json&weaid=" + city,
					"UTF-8");
			System.out.println(s);
			JSONObject root = JSONObject.parseObject(s);
			JSONArray ary = root.getJSONArray("result");
			JSONObject obj = ary.getJSONObject(0);
			list.add(
					new String[] { obj.getString("lifeindex_uv_typenm"), obj.getString("lifeindex_uv_attr"), obj.getString("lifeindex_uv_dese") });
			list.add(
					new String[] { obj.getString("lifeindex_xt_typenm"), obj.getString("lifeindex_xt_attr"), obj.getString("lifeindex_xt_dese") });
			list.add(
					new String[] { obj.getString("lifeindex_ct_typenm"), obj.getString("lifeindex_ct_attr"), obj.getString("lifeindex_ct_dese") });
			list.add(
					new String[] { obj.getString("lifeindex_xc_typenm"), obj.getString("lifeindex_xc_attr"), obj.getString("lifeindex_xc_dese") });
			list.add(
					new String[] { obj.getString("lifeindex_kq_typenm"), obj.getString("lifeindex_kq_attr"), obj.getString("lifeindex_kq_dese") });
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	public static List<Weather> getWeather(String city) {

		List<Weather> list = new ArrayList<Weather>();
		try {
			String s = getHtmlTextDocument(
					"http://api.k780.com:88/?app=weather.future&appkey=24557&sign=1b9830fa189d1494dd0355b61ee69f63&format=json&weaid=" + city,
					"UTF-8");
			System.out.println(s);
			JSONObject root = JSONObject.parseObject(s);
			JSONArray ary = root.getJSONArray("result");
			String cdate = DateUtil.getCurrentTime();
			for (int i = 0; i < ary.size(); i++) {
				JSONObject obj = ary.getJSONObject(i);

				String hign = obj.getString("temp_high");
				int whign = Integer.valueOf(hign);

				String low = obj.getString("temp_low");
				int wlow = Integer.valueOf(low);

				Weather w = new Weather();
				//w.setAddDate(cdate);
				w.setAddDate(obj.getString("days"));
				w.setCity(city);
				w.setFengli(obj.getString("winp"));
				w.setFengxiang(obj.getString("wind"));
				w.setWtype(obj.getString("weather"));
				w.setWhign(whign);
				w.setWlow(wlow);
				w.setIcon1(obj.getString("weather_icon"));
				w.setIcon2(obj.getString("weather_icon1"));
				list.add(w);

				cdate = DateUtil.addDays(cdate, 1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	public static String getHtmlTextDocument(String url, String charset) {
		log.info(url);
		CloseableHttpClient httpClient = HttpClients.createDefault();
		CloseableHttpResponse response = null;
		try {
			HttpGet getMethod = null;
			getMethod = new HttpGet(url);
			getMethod.setHeader("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
			getMethod.setHeader("Accept-Encoding", "gzip, deflate");
			getMethod.setHeader("Accept-Language", "zh-cn,zh;q=0.8,en-us;q=0.5,en;q=0.3");
			getMethod.setHeader("Cache-Control", "max-age=0");
			getMethod.setHeader("Connection", "keep-alive");
			getMethod.setHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:30.0) Gecko/20100101 Firefox/30.0");
			getMethod.setHeader("Content-Type", "application/x-www-form-urlencoded");
			RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(15000).setConnectTimeout(15000).build();// 设置请求和传输超时时间
			getMethod.setConfig(requestConfig);
			response = httpClient.execute(getMethod);
			//System.out.println(EntityUtils.toString(response.getEntity()));
			int status = response.getStatusLine().getStatusCode();
			log.info("返回状态: " + status);
			// 连接返回的状态码
			if (HttpStatus.SC_OK == status) {
				// 获取到的内容
				String ret = EntityUtils.toString(response.getEntity(), charset);
				return ret;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				response.close();
			} catch (Exception e1) {
			}
			try {
				httpClient.close();
			} catch (Exception e) {
			}
		}
		return null;
	}

	public static Document df(String url, File file) {
		CloseableHttpClient httpClient = HttpClients.createDefault();
		CloseableHttpResponse response = null;
		try {
			HttpGet getMethod = null;
			getMethod = new HttpGet(url);
			getMethod.setHeader("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
			getMethod.setHeader("Accept-Encoding", "gzip, deflate");
			getMethod.setHeader("Accept-Language", "zh-cn,zh;q=0.8,en-us;q=0.5,en;q=0.3");
			getMethod.setHeader("Cache-Control", "max-age=0");
			getMethod.setHeader("Connection", "keep-alive");
			getMethod.setHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:30.0) Gecko/20100101 Firefox/30.0");
			getMethod.setHeader("Content-Type", "application/x-www-form-urlencoded");
			//getMethod.setHeader("Referer", "https://www.google.com");
			RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(15000).setConnectTimeout(15000).build();// 设置请求和传输超时时间
			getMethod.setConfig(requestConfig);
			response = httpClient.execute(getMethod);
			HttpEntity entity = response.getEntity();
			InputStream in = entity.getContent();
			FileOutputStream fout = new FileOutputStream(file);
			int l = -1;
			byte[] tmp = new byte[1024];
			while ((l = in.read(tmp)) != -1) {
				fout.write(tmp, 0, l);
				// 注意这里如果用OutputStream.write(buff)的话，图片会失真，大家可以试试
			}
			fout.flush();
			fout.close();

			in.close();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				response.close();
			} catch (Exception e1) {
			}
			try {
				httpClient.close();
			} catch (Exception e) {
			}
		}
		return null;
	}

	public static String getUrlFileContent(String url, String charset) {

		// String url="http://www.baidu.com";
		String result = "";
		BufferedReader in = null;
		try {
			URL realUrl = new URL(url);
			URLConnection connection = realUrl.openConnection();
			connection.connect();
			InputStream urlStream = new GZIPInputStream(connection.getInputStream());
			in = new BufferedReader(new InputStreamReader(urlStream, charset));
			String line = "";
			while ((line = in.readLine()) != null) {
				result += line;
			}

		} catch (Exception e) {
			System.out.print("发送GET请求出现异常！" + e);
			e.printStackTrace();
		} finally {
			try {
				if (in != null) {
					in.close();
				}
			} catch (Exception e2) {
			}
		}

		return result;
	}

	public static Document getHtmlDocument(String url, String charset) {
		log.info(url);
		CloseableHttpClient httpClient = HttpClients.createDefault();
		CloseableHttpResponse response = null;
		try {
			HttpGet getMethod = null;
			getMethod = new HttpGet(url);
			getMethod.setHeader("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
			getMethod.setHeader("Accept-Encoding", "gzip, deflate");
			getMethod.setHeader("Accept-Language", "zh-cn,zh;q=0.8,en-us;q=0.5,en;q=0.3");
			getMethod.setHeader("Cache-Control", "max-age=0");
			getMethod.setHeader("Connection", "keep-alive");
			getMethod.setHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:30.0) Gecko/20100101 Firefox/30.0");
			getMethod.setHeader("Content-Type", "application/x-www-form-urlencoded");
			RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(15000).setConnectTimeout(15000).build();// 设置请求和传输超时时间
			getMethod.setConfig(requestConfig);
			response = httpClient.execute(getMethod);
			//System.out.println(EntityUtils.toString(response.getEntity()));
			int status = response.getStatusLine().getStatusCode();
			log.info("返回状态: " + status);
			// 连接返回的状态码
			if (HttpStatus.SC_OK == status) {
				// 获取到的内容
				Document doc = null;
				try {
					doc = Jsoup.parse(response.getEntity().getContent(), charset, url);
				} catch (Exception e) {
					//e.printStackTrace();
				}
				return doc;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				response.close();
			} catch (Exception e1) {
			}
			try {
				httpClient.close();
			} catch (Exception e) {
			}
		}
		return null;
	}

	public static String StringFilter(String str) {
		try {
			String regEx = "[`~!@#$%^&*()+=|{}':;',\\[\\].<>/?~！@#￥%……&*（）——+|{}【】‘；：”“’。，、？]";
			Pattern p = Pattern.compile(regEx);
			Matcher m = p.matcher(str);
			return m.replaceAll("").trim();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new Date().getTime() + "";
	}

	public static Document getHtmlDocument(String url) {
		try {

			// Document doc = Jsoup.connect(url).timeout(30000).get();
			Document doc = Jsoup.parse(new URL(url).openStream(), "GBK", url);
			return doc;
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("获取网页内容出错:" + e.getMessage());
		}
		return null;
	}

	public static List<String> getDocumentUrl(Document doc) {
		List<String> urls = new ArrayList<String>();
		if (doc == null) {
			return urls;
		}
		Elements temp = doc.getElementsByTag("body");
		if (temp == null || temp.size() == 0) {
			return urls;
		}
		Element body = temp.first();
		Elements els = body.getElementsByTag("a");
		if (els.size() <= 0) {
			return urls;
		}
		for (Element el : els) {
			String url = el.attr("href");
			if (isUrl(url)) {
				urls.add(url);
			}
		}

		return urls;
	}

	public static String getDocumentText(Document doc) {
		Elements temp = doc.getElementsByTag("body");
		if (temp == null || temp.size() == 0) {
			return "";
		}
		Element body = temp.first();
		return body.text();
	}

	public static boolean isUrl(String url) {
		if (StringUtils.isBlank(url)) {
			return false;
		}
		if (!(url.startsWith("http:") || url.startsWith("https:"))) {
			return false;
		}
		return true;

	}

	public static boolean writeToFile(String strUrl, File file) {
		BufferedInputStream bis = null;
		HttpURLConnection httpURLConnection = null;
		// FtpURLConnection ftpconnection = null;
		// URLConnection con = null;
		FileOutputStream fout = null;
		try {
			URL url = null;
			url = new URL(strUrl);

			httpURLConnection = (HttpURLConnection) url.openConnection();
			httpURLConnection.setRequestProperty("User-Agent", "Mozilla/4.0 (compatible; MSIE 5.0; Windows NT; DigExt)");
			httpURLConnection.setRequestMethod("GET");
			httpURLConnection.connect();

			// String type =
			// HttpURLConnection.guessContentTypeFromStream(httpURLConnection.getInputStream());
			String type = HttpURLConnection.guessContentTypeFromStream(new BufferedInputStream(httpURLConnection.getInputStream()));
			log.info(type);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {

			} catch (Exception e) {
			}
			try {
				bis.close();
			} catch (Exception e) {
			}
			try {
				fout.close();
			} catch (Exception e) {
			}
		}
		return false;
	}

}
// http://www.paper.edu.cn/index.php/default/journal/downCount/journal-1001-7232(1999)02-0025-26
// http://www.paper.edu.cn/index.php/default/journal/downCount/journal-1001-7232(1999)02-0025-26
