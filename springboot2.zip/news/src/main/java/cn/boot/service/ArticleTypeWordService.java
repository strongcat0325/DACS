package cn.boot.service;

import java.util.ArrayList;
import java.util.List;

public class ArticleTypeWordService {
    public List<String> findTopWords(String id) {
        return new ArrayList<>();
    }
}
