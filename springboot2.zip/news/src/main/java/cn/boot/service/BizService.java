package cn.boot.service;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.boot.common.BaseService;
import cn.boot.dao.SysDaoImpl;
import cn.boot.entity.Article;
import cn.boot.entity.ArticleComment;
import cn.boot.entity.Cai;
import cn.boot.entity.UserFav;
import cn.boot.entity.UserLog;
import cn.boot.entity.Zan;
import cn.boot.entity.main.SimpleUser;
import cn.boot.entity.main.SysUser;
import cn.boot.entity.main.User;
import util.DateUtil;
import util.MD5;
import util.Page;

@Service("bizService")
@Repository
@Transactional(rollbackFor = Exception.class)
public class BizService extends BaseService {
	@Autowired
	private SysDaoImpl dao;

	public <T> T unique(final String hql, final Object... paramlist) {
		return dao.unique(hql, paramlist);
	}

	@SuppressWarnings("unchecked")
	public void deleteSysUser(Class<SysUser> class1, String ids) {
		List<User> list = dao.queryByHQL("from User where uname in(select user.uname from SysUser where id in (" + ids + "))");
		for (User user : list) {
			dao.delete(user);
		}
	}

	@SuppressWarnings("unchecked")
	public void deleteSimpleUser(Class<SimpleUser> class1, String ids) {
		List<User> list = dao.queryByHQL("from User where uname in(select user.uname from SimpleUser where id in (" + ids + "))");
		for (User user : list) {
			dao.delete(user);
		}
	}

	@SuppressWarnings("rawtypes")
	public List queryByHQL(String hql, Object... values) {
		return dao.queryByHQL(hql, values);
	}

	public void addSimpleUser(SimpleUser obj) {
		User user = obj.getUser();
		MD5 md = new MD5();
		user.setUserPassword(md.getMD5ofStr(user.getUserPassword()));
		dao.save(user);
		dao.save(obj);
	}

	public void updateSimpleUser(SimpleUser obj) {
		SimpleUser temp = (SimpleUser) dao.get(SimpleUser.class, obj.getId());
		User user = temp.getUser();
		user.setUserAddress(obj.getUser().getUserAddress());
		user.setUserBirth(obj.getUser().getUserBirth());
		user.setUserEmail(obj.getUser().getUserEmail());
		user.setUserGender(obj.getUser().getUserGender());
		user.setUserName(obj.getUser().getUserName());
		user.setUserPhone(obj.getUser().getUserPhone());
		if (StringUtils.isNotBlank(obj.getUser().getUserPassword())) {
			MD5 md = new MD5();
			user.setUserPassword(md.getMD5ofStr(obj.getUser().getUserPassword()));
		}
		dao.merge(user);
		obj.setUser(user);
		dao.merge(obj);

	}

	/**
	 * 添加对象
	 * 
	 * @param obj
	 */
	public void add(Object obj) {
		dao.save(obj);
	}

	/**
	 * 修改对象
	 * 
	 * @param obj
	 */
	public void update(Object obj) {
		dao.merge(obj);
	}

	/**
	 * 根据id获取对象
	 * 
	 * @param clazz
	 * @param id
	 * @return
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public <T> T get(Class clazz, Serializable id) {
		return (T) dao.get(clazz, id);
	}

	public void deleteUser(String ids) {
		dao.deleteByIds(User.class, ids);
	}

	@SuppressWarnings("rawtypes")
	public void delete(Class clazz, String ids) {
		dao.deleteByIds(clazz, ids);
	}

	public Object findUser(String type, String userid, String pwd) {
		return dao.queryUser(type, userid, pwd);
	}

	public User findUser(String userid) {
		return dao.queryUser(userid);
	}

	public Page findUser(Page page) {
		return dao.list(page, "User");
	}

	@SuppressWarnings("rawtypes")
	public Page find(Page page, Class clazz) {
		return dao.list(page, clazz.getSimpleName());
	}

	@SuppressWarnings("rawtypes")
	public List findAll(Class clazz) {
		return dao.queryByHQL("from " + clazz.getSimpleName());
	}

	public void addSysUser(SysUser obj) {
		User user = obj.getUser();
		MD5 md = new MD5();
		user.setUserPassword(md.getMD5ofStr(user.getUserPassword()));
		dao.save(user);
		dao.save(obj);
	}

	public void updateSysUser(SysUser obj) {
		SysUser temp = (SysUser) dao.get(SysUser.class, obj.getId());
		User user = temp.getUser();
		user.setUserAddress(obj.getUser().getUserAddress());
		user.setUserBirth(obj.getUser().getUserBirth());
		user.setUserEmail(obj.getUser().getUserEmail());
		user.setUserGender(obj.getUser().getUserGender());
		user.setUserName(obj.getUser().getUserName());
		user.setUserPhone(obj.getUser().getUserPhone());
		if (StringUtils.isNotBlank(obj.getUser().getUserPassword())) {
			MD5 md = new MD5();
			user.setUserPassword(md.getMD5ofStr(obj.getUser().getUserPassword()));
		}
		dao.merge(user);
		obj.setUser(user);
		dao.merge(obj);
	}

	@SuppressWarnings("rawtypes")
	public List findAll(Class clazz, Map<String, Object> params) {
		return dao.findAll(clazz, params);
	}

	public void addZan(Zan z) {
		dao.save(z);
		dao.updateByHQL("update Article set zanCount=zanCount+1 where id=?", z.getArticle().getId());
	}

	public void addCai(Cai z) {
		dao.save(z);
		dao.updateByHQL("update Article set caiCount=caiCount+1 where id=?", z.getArticle().getId());
	}

	public void updateView(int uid) {
		dao.updateByHQL("update Article set viewCount=viewCount+1 where id=?", uid);
	}

	public void updateRead(Integer id) {
		dao.updateByHQL("update ArticleComment set userread='是' where article.id=?", id);
	}

	public List<?> findNew10() {
		return dao.queryByHQLLimit("from Article order by id desc", 0, 10);
	}

	public List<Article> findZan5() {
		return dao.queryByHQLLimit("from Article order by zanCount desc", 0, 5);
	}

	public List<Article> findView5() {
		return dao.queryByHQLLimit("from Article order by viewCount desc", 0, 5);
	}

	public List<ArticleComment> findCommentNew5() {
		return dao.queryByHQLLimit("from ArticleComment order by id desc", 0, 5);
	}

	public void addUserFav(UserFav z) {
		dao.save(z);
		dao.updateByHQL("update Article set favCount=favCount+1 where id=?", z.getArticle().getId());

	}

	public Page findArticleComment(Page p, Class<ArticleComment> class1) {
		return dao.list(p, class1.getSimpleName(), "rcount desc");
	}

	public void addUserLog(int articleId, String type) {
		UserLog l = new UserLog();
		l.setAddDate(DateUtil.getCurrentTime());
		l.setArticleId(articleId);
		l.setType(type);
		dao.save(l);
	}

}
