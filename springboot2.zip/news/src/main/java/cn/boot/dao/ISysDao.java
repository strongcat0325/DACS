package cn.boot.dao;

import java.util.List;

import cn.boot.common.BaseDao;
import cn.boot.entity.main.User;

public interface ISysDao extends BaseDao{
	public void saveUser(User user);

	public Object queryUser(String type,String userid, String pwd) ;

	public User queryUser(String userid) ;

	@SuppressWarnings("rawtypes")
	public List queryByHQLLimit(String hql,int start,int max);
	public <T> T unique(final String hql, final Object... paramlist);
}
