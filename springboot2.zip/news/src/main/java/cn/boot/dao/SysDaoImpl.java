package cn.boot.dao;

import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import cn.boot.common.BaseHibernateDao;
import cn.boot.entity.main.User;

@Repository
public class SysDaoImpl extends BaseHibernateDao implements ISysDao {
	public void saveUser(User user) {
		save(user);
	}

	public Object queryUser(String type, String userid, String pwd) {
		return unique("from " + type + " where user.uname='" + userid + "' and user.userPassword='" + pwd + "'");
	}

	public User queryUser(String userid) {
		return unique("from User where uname=?", userid);
	}

	@SuppressWarnings("rawtypes")
	public List queryByHQLLimit(final String hql, final int start, final int max) {
		Query query = getSession().createQuery(hql);
		query.setFirstResult(start);
		query.setMaxResults(max);
		return query.list();
	}

}
