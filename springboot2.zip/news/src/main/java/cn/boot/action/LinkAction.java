package cn.boot.action;

import java.util.LinkedList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import cn.boot.common.BaseAction;
import cn.boot.entity.Link;
import cn.boot.service.BizService;
import util.Constant;
import util.FieldUtil;
import util.MessageUtil;
import util.Page;

@Controller
@RequestMapping("/sys")
public class LinkAction extends BaseAction {
	private String		actionname	= "友情链接";
	private String		actionclass	= "Link";
	@Autowired
	private BizService	service;

	@RequestMapping(value = "/add2Link.do", method = RequestMethod.GET)
	public String add2() {
		request.setAttribute("actionname", actionname);
		request.setAttribute("actionclass", actionclass);
		return "sys/addLink";
	}

	@RequestMapping(value = "/getLink.do", method = RequestMethod.GET)
	public String get(int uid) {
		try {
			Link temp = (Link) service.get(Link.class, uid);
			request.setAttribute("modifybean", temp);

			request.setAttribute("actionname", actionname);
			request.setAttribute("actionclass", actionclass);
			return "sys/modifyLink";
		} catch (Exception e) {
			e.printStackTrace();
			MessageUtil.addMessage(request, "获取信息失败.");
			return ERROR;
		}
	}

	@RequestMapping(value = "/addLink.do")
	public String add(Link bean) {
		try {
			service.add(bean);
			MessageUtil.addMessage(request, "添加成功.");
			return SUCCESS;
		} catch (Exception e) {
			e.printStackTrace();
			MessageUtil.addMessage(request, "添加失败.");
			return ERROR;
		}

	}

	@RequestMapping(value = "/updateLink.do")
	public String update(Link bean) {
		try {
			service.update(bean);
			MessageUtil.addRelMessage(request, "更新成功.", "baseAdd");
			return SUCCESS;
		} catch (Exception e) {
			e.printStackTrace();
			MessageUtil.addMessage(request, "更新失败.");
			return ERROR;
		}
	}

	@RequestMapping(value = "/deleteLink.do")
	public String delete(String ids) {
		try {
			service.delete(Link.class, ids);
			MessageUtil.addRelMessage(request, "操作成功.", "mainquery");
			return SUCCESS;
		} catch (Exception e) {
			e.printStackTrace();
			MessageUtil.addMessage(request, "操作失败.");
			return ERROR;
		}
	}

	@RequestMapping(value = "/queryLink.do")
	public String query() {
		try {
			// 字段名称集合
			LinkedList<String> parmnames = new LinkedList<String>();
			// 字段值集合
			LinkedList<Object> parmvalues = new LinkedList<Object>();
			Page p = FieldUtil.createPage(request, Link.class, parmnames, parmvalues);

			//			if (parmnames.contains("type")) {
			//				actionname1 = (String) parmvalues.get(parmnames.indexOf("type"));
			//			}

			Page page = service.find(p, Link.class);
			session.setAttribute(Constant.SESSION_PAGE, page);

			request.setAttribute("actionname", actionname);
			request.setAttribute("actionclass", actionclass);
			return "sys/listLink";
		} catch (Exception e) {
			e.printStackTrace();
			return ERROR;
		}
	}
}
