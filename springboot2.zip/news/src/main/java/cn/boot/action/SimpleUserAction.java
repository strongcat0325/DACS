package cn.boot.action;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Date;
import java.util.LinkedList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import cn.boot.common.BaseAction;
import cn.boot.entity.main.SimpleUser;
import cn.boot.service.BizService;
import util.Constant;
import util.FieldUtil;
import util.MessageUtil;
import util.Page;

@Controller
@RequestMapping("/sys")
public class SimpleUserAction extends BaseAction {
	private String			actionname	= "用户";
	private String			actionclass	= "SimpleUser";
	@Autowired
	private BizService	service;

	@RequestMapping(value = "/add2SimpleUser.do", method = RequestMethod.GET)
	public String add2() {
		request.setAttribute("actionname", actionname);
		request.setAttribute("actionclass", actionclass);
		return "sys/addSimpleUser";
	}

	@RequestMapping(value = "/getSimpleUser.do", method = RequestMethod.GET)
	public String get(int uid) {
		try {
			SimpleUser bean = (SimpleUser) service.get(SimpleUser.class, uid);
			request.setAttribute("modifybean", bean);

			request.setAttribute("actionname", actionname);
			request.setAttribute("actionclass", actionclass);
			return "sys/modifySimpleUser";
		} catch (Exception e) {
			e.printStackTrace();
			MessageUtil.addMessage(request, "获取信息失败.");
			return ERROR;
		}
	}

	@RequestMapping(value = "/deleteSimpleUser.do")
	public String delete(String ids) {
		try {
			service.deleteSimpleUser(SimpleUser.class, ids);
			MessageUtil.addRelMessage(request, "删除信息成功.", "mainquery");
			return SUCCESS;
		} catch (Exception e) {
			e.printStackTrace();
			MessageUtil.addMessage(request, "删除信息失败.");
			return ERROR;
		}
	}

	@RequestMapping(value = "/addSimpleUser.do")
	public String add(SimpleUser bean) {
		try {
			service.addSimpleUser(bean);
			MessageUtil.addMessage(request, "添加成功.");
			return SUCCESS;
		} catch (Exception e) {
			e.printStackTrace();
			MessageUtil.addMessage(request, "添加失败.");
			return ERROR;
		}

	}

	@RequestMapping(value = "/updateSimpleUser.do")
	public String update(SimpleUser bean) {
		try {
//			String photo = FileUtil.uploadFile(request, "resfile");
//			if (StringUtils.isNoneBlank(photo)) {
//				bean.setPhoto(photo);
//			}
			service.updateSimpleUser(bean);
			MessageUtil.addMessage(request, "更新成功.");
			return SUCCESS;
		} catch (Exception e) {
			e.printStackTrace();
			MessageUtil.addMessage(request, "更新失败.");
			return ERROR;
		}
	}

	@RequestMapping(value = "/querySimpleUser.do")
	public String query() {
		try {
			// 字段名称集合
			LinkedList<String> parmnames = new LinkedList<String>();
			// 字段值集合
			LinkedList<Object> parmvalues = new LinkedList<Object>();
			Page p = FieldUtil.createPage(request, SimpleUser.class, parmnames, parmvalues);

			//			if (parmnames.contains("type")) {
			//				actionname1 = (String) parmvalues.get(parmnames.indexOf("type"));
			//			}

			Page page = service.find(p, SimpleUser.class);
			session.setAttribute(Constant.SESSION_PAGE, page);

			request.setAttribute("actionname", actionname);
			request.setAttribute("actionclass", actionclass);
			return "sys/listSimpleUser";
		} catch (Exception e) {
			e.printStackTrace();
			return ERROR;
		}
	}

	/**
	 <textarea class="editor" name="content" rows="20" cols="100" tools="simple" upImgUrl="${ctx}/sys/imageUpload.do" upImgExt="jpg,jpeg,gif,png">${modifybean.content }</textarea>
	 */
	@RequestMapping(value = "/imageUpload.do", method = RequestMethod.POST)
	@ResponseBody
	public String image(HttpServletRequest request, HttpSession session, @RequestParam("filedata") MultipartFile file) throws Exception {
		String realPath = request.getSession().getServletContext().getRealPath("/resource") + File.separator;
		log.info(realPath);
		File dir = new File(realPath);
		if (!dir.exists()) {
			dir.mkdirs();
		}

		// 以下是真正的上传部分
		String error = "";
		// 取得原文件名	
		String originName = file.getOriginalFilename();
		// 取得文件后缀
		String fileExt = originName.substring(originName.lastIndexOf(".") + 1);
		// 按时间戳生成图片文件名
		String picture = new Date().getTime() + "." + fileExt;
		try {
			IOUtils.copy(file.getInputStream(), new FileOutputStream(new File(dir, picture)));
		} catch (Exception e) {
			e.printStackTrace();
			error = e.getMessage();
		}
		String http = "http://" + request.getServerName() + ":" + request.getServerPort() + request.getContextPath();
		String url = http + "/" + "resource" + "/" + picture;
		// {'err':'',msg:{'url':'XXX/upload/images/2012/11_11/20121111015039.jpg','localname':'我的头像.jpg','id':'63'}}
		String json = String.format("{'err':'%s',msg:{'url':'%s','localname':'%s'}}", error, url, originName);
		return json;
	}

}
