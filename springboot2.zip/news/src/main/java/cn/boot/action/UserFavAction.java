package cn.boot.action;

import java.util.LinkedList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import cn.boot.common.BaseAction;
import cn.boot.entity.UserFav;
import cn.boot.service.BizService;
import util.Constant;
import util.FieldUtil;
import util.MessageUtil;
import util.Page;

@Controller
@RequestMapping("/sys")
public class UserFavAction extends BaseAction {
	private String		actionname	= "收藏";
	private String		actionclass	= "UserFav";
	@Autowired
	private BizService	service;

	@RequestMapping(value = "/add2UserFav.do", method = RequestMethod.GET)
	public String add2() {
		request.setAttribute("actionname", actionname);
		request.setAttribute("actionclass", actionclass);
		return "sys/addUserFav";
	}

	@RequestMapping(value = "/getUserFav.do", method = RequestMethod.GET)
	public String get(int uid) {
		try {
			UserFav temp = (UserFav) service.get(UserFav.class, uid);
			request.setAttribute("modifybean", temp);

			request.setAttribute("actionname", actionname);
			request.setAttribute("actionclass", actionclass);
			return "sys/modifyUserFav";
		} catch (Exception e) {
			e.printStackTrace();
			MessageUtil.addMessage(request, "获取信息失败.");
			return ERROR;
		}
	}

	@RequestMapping(value = "/addUserFav.do")
	public String add(UserFav bean) {
		try {
			service.add(bean);
			MessageUtil.addMessage(request, "添加成功.");
			return SUCCESS;
		} catch (Exception e) {
			e.printStackTrace();
			MessageUtil.addMessage(request, "添加失败.");
			return ERROR;
		}

	}

	@RequestMapping(value = "/updateUserFav.do")
	public String update(UserFav bean) {
		try {
			service.update(bean);
			MessageUtil.addRelMessage(request, "更新成功.", "baseAdd");
			return SUCCESS;
		} catch (Exception e) {
			e.printStackTrace();
			MessageUtil.addMessage(request, "更新失败.");
			return ERROR;
		}
	}

	@RequestMapping(value = "/deleteUserFav.do")
	public String delete(String ids) {
		try {
			service.delete(UserFav.class, ids);
			MessageUtil.addRelMessage(request, "操作成功.", "mainquery");
			return SUCCESS;
		} catch (Exception e) {
			e.printStackTrace();
			MessageUtil.addMessage(request, "操作失败.");
			return ERROR;
		}
	}

	@RequestMapping(value = "/queryUserFav.do")
	public String query() {
		try {
			// 字段名称集合
			LinkedList<String> parmnames = new LinkedList<String>();
			// 字段值集合
			LinkedList<Object> parmvalues = new LinkedList<Object>();
			Page p = FieldUtil.createPage(request, UserFav.class, parmnames, parmvalues);

			parmnames.add("user.id");
			parmvalues.add(getSimpleUser().getId());

			Page page = service.find(p, UserFav.class);
			session.setAttribute(Constant.SESSION_PAGE, page);

			request.setAttribute("actionname", actionname);
			request.setAttribute("actionclass", actionclass);
			return "sys/listUserFav";
		} catch (Exception e) {
			e.printStackTrace();
			return ERROR;
		}
	}
}
