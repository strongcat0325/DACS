package cn.boot.action;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;

import cn.boot.common.BaseAction;
import cn.boot.entity.Article;
import cn.boot.entity.ArticleComment;
import cn.boot.entity.ArticleCommentReply;
import cn.boot.entity.Cai;
import cn.boot.entity.Link;
import cn.boot.entity.News;
import cn.boot.entity.UserFav;
import cn.boot.entity.Weather;
import cn.boot.entity.Zan;
import cn.boot.entity.main.SimpleUser;
import cn.boot.service.BizService;
import util.Constant;
import util.DateUtil;
import util.FetchUtil;
import util.FieldUtil;
import util.Page;

@Controller
@RequestMapping("/com")
public class WebAction extends BaseAction {
	@Autowired
	private BizService service;

	@RequestMapping(value = "/tianqi.do")
	public String tianqi(String city) {
		try {
			getSide();
			if (StringUtils.isBlank(city)) {
				return "forward:/qiantai/tianqi.jsp";
			}
			List<Weather> list = FetchUtil.getWeather(city);
			if (list != null && list.size() > 0) {
				String date = "";
				String datahign = "";
				String datalow = "";
				for (Weather w : list) {
					String htemp = "{y: " + w.getWhign() + ",fengxiang:'" + w.getFengxiang() + "',fengli:'" + w.getFengli() + "',wtype:'"
							+ w.getWtype() + "',icon1:'" + w.getIcon1() + "',icon2:'" + w.getIcon2() + "'}";
					String ltemp = "{y: " + w.getWlow() + ",icon1:'" + w.getIcon2() + "'}";
					datahign += htemp + ",";
					datalow += ltemp + ",";
					date += "'" + w.getAddDate() + "',";
				}
				date = date.substring(0, date.length() - 1);
				datahign = datahign.substring(0, datahign.length() - 1);
				datalow = datalow.substring(0, datalow.length() - 1);

				putRequestValue("datejson", date);
				putRequestValue("datahignjson", datahign);
				putRequestValue("datalowjson", datalow);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return "forward:/qiantai/tianqi.jsp";
	}

	@RequestMapping(value = "/addComment.do")
	public String addComment(ArticleComment bean) {
		try {
			SimpleUser user = getSimpleUser();
			if (user == null) {
				putSessionValue("errorMessage", "请先登陆后评价");
				return "redirect:/com/getArticle.do?uid=" + bean.getArticle().getId();
			}
			bean.setAddDate(DateUtil.getCurrentTime());
			bean.setUser(user);
			bean.setRcount(0);
			//			Article a = service.get(Article.class, bean.getArticle().getId());
			service.add(bean);

			putSessionValue("errorMessage", "评价成功");
			service.addUserLog(bean.getArticle().getId(), "评论");
		} catch (Exception e) {
			e.printStackTrace();
			putSessionValue("errorMessage", "评价失败");
		}

		return "redirect:/com/getArticle.do?uid=" + bean.getArticle().getId();
	}

	@RequestMapping(value = "/addArticleCommentReply.do")
	public String addArticleCommentReply(ArticleCommentReply bean) {
		ArticleComment ac = service.get(ArticleComment.class, bean.getArticleComment().getId());
		try {
			SimpleUser user = getSimpleUser();
			if (user == null) {
				putSessionValue("errorMessage", "请先登陆后回复");
				return "redirect:/com/getArticle.do?uid=" + ac.getArticle().getId();
			}
			bean.setAddDate(DateUtil.getCurrentTime());
			bean.setUser(user);
			service.add(bean);

			putSessionValue("errorMessage", "回复成功");

		} catch (Exception e) {
			e.printStackTrace();
			putSessionValue("errorMessage", "回复失败");
		}

		return "redirect:/com/getArticle.do?uid=" + ac.getArticle().getId();
	}

	@RequestMapping(value = "/jubao.do")
	@ResponseBody
	public Object jubao(int uid) {
		JSONObject ret = new JSONObject();
		try {
			ArticleComment c = service.get(ArticleComment.class, uid);
			c.setRcount(c.getRcount() + 1);
			service.update(c);
			ret.put("msg", "举报成功");
		} catch (Exception e) {
			ret.put("msg", "举报失败");
			e.printStackTrace();
		}

		return ret;
	}

	@SuppressWarnings({ "rawtypes" })
	@RequestMapping(value = "/zan.do")
	public String zan1(int uid) {
		try {
			SimpleUser user = getSimpleUser();
			if (user == null) {
				putSessionValue("errorMessage", "请先登陆后点赞");
				return "redirect:/com/getArticle.do?uid=" + uid;
			}
			List templist = service.queryByHQL("from Zan where article.id=? and user.id=?", uid, getSimpleUser().getId());
			if (templist.size() > 0) {
				putSessionValue("errorMessage", "您已经点赞过了");
				return "redirect:/com/getArticle.do?uid=" + uid;
			}

			Zan z = new Zan();
			z.setArticle(service.get(Article.class, uid));
			z.setUser(user);
			service.addZan(z);

			putSessionValue("errorMessage", "点赞成功");
			service.addUserLog(uid, "点赞");
		} catch (Exception e) {
			e.printStackTrace();
			putSessionValue("errorMessage", "点赞失败");
		}

		return "redirect:/com/getArticle.do?uid=" + uid;
	}

	@SuppressWarnings({ "rawtypes" })
	@RequestMapping(value = "/cai.do")
	public String cai1(int uid) {
		try {
			SimpleUser user = getSimpleUser();
			if (user == null) {
				putSessionValue("errorMessage", "请先登陆后操作");
				return "redirect:/com/getArticle.do?uid=" + uid;
			}
			List templist = service.queryByHQL("from Cai where article.id=? and user.id=?", uid, getSimpleUser().getId());
			if (templist.size() > 0) {
				putSessionValue("errorMessage", "您已经踩过了");
				return "redirect:/com/getArticle.do?uid=" + uid;
			}

			Cai z = new Cai();
			z.setArticle(service.get(Article.class, uid));
			z.setUser(user);
			service.addCai(z);

			putSessionValue("errorMessage", "操作成功");
			service.addUserLog(uid, "踩");
		} catch (Exception e) {
			e.printStackTrace();
			putSessionValue("errorMessage", "操作失败");
		}

		return "redirect:/com/getArticle.do?uid=" + uid;
	}

	@SuppressWarnings({ "rawtypes" })
	@RequestMapping(value = "/fav.do")
	public String fav1(int uid) {
		try {
			SimpleUser user = getSimpleUser();
			if (user == null) {
				putSessionValue("errorMessage", "请先登陆后收藏");
				return "redirect:/com/getArticle.do?uid=" + uid;
			}
			List templist = service.queryByHQL("from UserFav where article.id=? and user.id=?", uid, getSimpleUser().getId());
			if (templist.size() > 0) {
				putSessionValue("errorMessage", "您已经收藏过了");
				return "redirect:/com/getArticle.do?uid=" + uid;
			}

			UserFav z = new UserFav();
			z.setArticle(service.get(Article.class, uid));
			z.setUser(user);
			service.addUserFav(z);

			putSessionValue("errorMessage", "收藏成功");
			service.addUserLog(uid, "收藏");
		} catch (Exception e) {
			e.printStackTrace();
			putSessionValue("errorMessage", "收藏失败");
		}

		return "redirect:/com/getArticle.do?uid=" + uid;
	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/getArticle.do")
	public String getArticle1(int uid) {
		try {
			SimpleUser user = getSimpleUser();
			Article article = service.get(Article.class, uid);

			putRequestValue("item", article);
			List<ArticleComment> commentList = service.queryByHQL("from ArticleComment where article.id=? order by id desc", uid);
			for (ArticleComment articleComment : commentList) {
				List queryByHQL = service.queryByHQL("from ArticleCommentReply where articleComment.id=? order by id desc",
						articleComment.getId());
				articleComment.setList(queryByHQL);
			}
			putRequestValue("commentList", commentList);

			List<?> xglist = service.queryByHQL("from Article where articelType.id=? order by zanCount desc",
					article.getArticelType().getId());
			if (xglist.size() > 8) {
				xglist = xglist.subList(0, 8);
			}
			putRequestValue("xglist", xglist);
			service.updateView(uid);

			getSide();
			service.addUserLog(uid, "浏览");
		} catch (Exception e) {
			e.printStackTrace();
		}

		return "forward:/qiantai/content.jsp";
	}

	@RequestMapping(value = "/list.do")
	public String list() {
		try {
			// 字段名称集合
			LinkedList<String> parmnames = new LinkedList<String>();
			// 字段值集合
			LinkedList<Object> parmvalues = new LinkedList<Object>();
			Page p = FieldUtil.createPage(request, Article.class, parmnames, parmvalues);

			//			parmnames.add("status");
			//			parmvalues.add("审核通过");

			Page page = service.find(p, Article.class);
			session.setAttribute(Constant.SESSION_PAGE, page);

			getSide();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return "forward:/qiantai/list.jsp";
	}

	@RequestMapping(value = "/index.do")
	public String index() {
		List<?> alist = service.findNew10();
		if (alist.size() > 10) {
			alist = alist.subList(0, 10);
		}
		putRequestValue("newList", alist);
		getSide();
		return "forward:/qiantai/index.jsp";
	}

	@RequestMapping(value = "/about.do")
	public String about() {
		getSide();
		return "forward:/qiantai/about.jsp";
	}

	@RequestMapping(value = "/link.do")
	public String link() {
		putRequestValue("linkList", service.findAll(Link.class));
		getSide();
		return "forward:/qiantai/friendly.jsp";
	}

	@RequestMapping(value = "/listNews.do")
	public String listNews() {
		putRequestValue("newsList", service.queryByHQL("from News order by id desc"));
		getSide();
		return "forward:/qiantai/listNews.jsp";
	}

	@RequestMapping(value = "/getNews.do")
	public String getNews(int uid) {
		putRequestValue("item", service.get(News.class, uid));
		getSide();
		return "forward:/qiantai/news.jsp";
	}

	@RequestMapping(value = "/toUser.do")
	public String toUser() {
		return "main";
	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/unread.do")
	public String unread() {
		SimpleUser user = getSimpleUser();
		List<Article> all = new ArrayList<Article>();
		if (user != null) {
			List<Article> alist = service.queryByHQL("from Article where user.id=?", user.getId());
			for (Article article : alist) {
				List<?> templist = service.queryByHQL("from ArticleComment where article.id=? and userread='否'", article.getId());
				if (templist.size() > 0) {
					all.add(article);
				}
			}
		}
		putRequestValue("unreadList", all);
		getSide();
		return "forward:/qiantai/unread.jsp";
	}

	private void getSide() {
		putRequestValue("typeList", service.queryByHQL("from ArticelType order by id"));
		List<?> toplist = service.findZan5();
		putRequestValue("topList", toplist);

		List<?> hotlist = service.findView5();
		putRequestValue("hotList", hotlist);

		List<ArticleComment> newCommentList = service.findCommentNew5();
		putRequestValue("newCommentList", newCommentList);

	}

}
