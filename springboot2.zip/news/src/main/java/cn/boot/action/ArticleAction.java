package cn.boot.action;

import java.util.*;
import java.util.stream.Collectors;

import cn.boot.entity.ArticleTypeWord;
import cn.boot.tools.NewsClassifyTool;
import com.qianxinyao.analysis.jieba.keyword.Keyword;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import cn.boot.common.BaseAction;
import cn.boot.entity.ArticelType;
import cn.boot.entity.Article;
import cn.boot.service.BizService;
import cn.boot.tools.JiebaAnalysisTool;
import util.Constant;
import util.DateUtil;
import util.FieldUtil;
import util.MessageUtil;
import util.Page;

@Controller
@RequestMapping("/sys")
public class ArticleAction extends BaseAction {
	private String			actionname	= "新闻";
	private String			actionclass	= "Article";
	@Autowired
	private BizService	service;

	@RequestMapping(value = "/anlNews.do")
	public String anlNews() {
		JSONArray ary = new JSONArray();
		List<ArticelType> queryByHQL = service.queryByHQL("from ArticelType");
		for (ArticelType articelType : queryByHQL) {
			JSONObject obj = new JSONObject();

			JSONArray datas = new JSONArray();
			Long count = service.unique("select sum(viewCount) from Article where articelType.id=?", articelType.getId());
			count = count == null ? 0 : count;
			datas.add(count);

			count = service.unique("select sum(zanCount) from Article where articelType.id=?", articelType.getId());
			count = count == null ? 0 : count;
			datas.add(count);
			count = service.unique("select sum(caiCount) from Article where articelType.id=?", articelType.getId());
			count = count == null ? 0 : count;
			datas.add(count);
			count = service.unique("select sum(favCount) from Article where articelType.id=?", articelType.getId());
			count = count == null ? 0 : count;
			datas.add(count);

			obj.put("name", articelType.getName());
			obj.put("data", datas);
			ary.add(obj);
		}

		putRequestValue("datas", ary.toJSONString());

		return "sys/anlNews";
	}

	@RequestMapping(value = "/anlWeek.do")
	public String anlWeek() {
		String date = DateUtil.getCurrentTime();
		String start = DateUtil.addDays(date, -6);
		JSONArray names = new JSONArray();
		JSONArray liulan = new JSONArray();
		JSONArray zan = new JSONArray();
		JSONArray cai = new JSONArray();
		JSONArray fav = new JSONArray();
		JSONArray ping = new JSONArray();

		while (true) {
			names.add(start);

			Long count = service.unique("select count(*) from UserLog where addDate=? and type=?", start, "浏览");
			count = count == null ? 0 : count;
			liulan.add(count);
			
			count = service.unique("select count(*) from UserLog where addDate=? and type=?", start, "点赞");
			count = count == null ? 0 : count;
			zan.add(count);
			
			count = service.unique("select count(*) from UserLog where addDate=? and type=?", start, "踩");
			count = count == null ? 0 : count;
			cai.add(count);
			
			count = service.unique("select count(*) from UserLog where addDate=? and type=?", start, "收藏");
			count = count == null ? 0 : count;
			fav.add(count);
			
			count = service.unique("select count(*) from UserLog where addDate=? and type=?", start, "评论");
			count = count == null ? 0 : count;
			ping.add(count);

			start = DateUtil.addDays(start, 1);
			if (start.compareTo(date) > 0)
				break;
		}
		
		putRequestValue("names", names.toJSONString());
		putRequestValue("liulan", liulan.toJSONString());
		putRequestValue("zan", zan.toJSONString());
		putRequestValue("cai", cai.toJSONString());
		putRequestValue("fav", fav.toJSONString());
		putRequestValue("ping", ping.toJSONString());
		return "sys/anlWeek";
	}

	@RequestMapping(value = "/add2Article.do", method = RequestMethod.GET)
	public String add2() {
		List<ArticelType> all = service.findAll(ArticelType.class);
		all.add(0, new ArticelType(0, "自动分类"));
		putRequestValue("list", all);
		request.setAttribute("actionname", actionname);
		request.setAttribute("actionclass", actionclass);
		return "sys/addArticle";
	}

	@RequestMapping(value = "/getArticle.do", method = RequestMethod.GET)
	public String get(int uid) {
		try {
			putRequestValue("list", service.findAll(ArticelType.class));
			Article temp = (Article) service.get(Article.class, uid);
			request.setAttribute("modifybean", temp);

			request.setAttribute("actionname", actionname);
			request.setAttribute("actionclass", actionclass);
			return "sys/modifyArticle";
		} catch (Exception e) {
			e.printStackTrace();
			MessageUtil.addMessage(request, "获取信息失败.");
			return ERROR;
		}
	}

	@RequestMapping(value = "/addArticle.do")
	public String add(Article bean) {
		if (bean.getArticelType().getId() != 0) {
			ArticelType curType = service.get(ArticelType.class, bean.getArticelType().getId());
			List<String> words =
			JiebaAnalysisTool.classify(bean).stream().map(Keyword::getName).collect(Collectors.toList());
			ArticleTypeWord curTypeWord = typeWordOfType(curType);
			Set<String> existedWords = null;
			if (curTypeWord.getWords() == null) {
				existedWords = new HashSet<>();
			} else {
				existedWords = new HashSet<>(Arrays.asList(curTypeWord.getWords().split(",")));
			}
			existedWords.addAll(words);
			String newWordStr = String.join(",", existedWords);
			curTypeWord.setWords(newWordStr);
			System.out.println(curTypeWord);
			service.add(curTypeWord);
		} else {
			ArticelType classifyType = null;
			double value = 0.0;
			List<ArticelType> allTypes = service.findAll(ArticelType.class);
			for (ArticelType type : allTypes) {
				String words = typeWordOfType(type).getWords();
				if (words == null || words.length() == 0) {
					continue;
				}
				List<String> curTypeWordList = Arrays.asList(words.split(","));
				double curValue = NewsClassifyTool.newsClassify(bean, curTypeWordList);
				if (curValue > value) {
					value = curValue;
					classifyType = type;
				}
			}
			if (classifyType == null) {
				MessageUtil.addMessage(request, "自动分类失败，请手动分类.");
				return ERROR;
			}
			bean.setArticelType(classifyType);
		}
		try {
			bean.setViewCount(0);
			bean.setZanCount(0);
			bean.setCaiCount(0);
			bean.setFavCount(0);
			bean.setAddDate(DateUtil.getCurrentTime(DateUtil.FULL));
			bean.setImgFile(FileUtil.uploadFile(request, "resfile"));
			service.add(bean);
			MessageUtil.addMessage(request, "添加成功.");
			return SUCCESS;
		} catch (Exception e) {
			e.printStackTrace();
			MessageUtil.addMessage(request, "添加失败.");
			return ERROR;
		}

	}

	@RequestMapping(value = "/updateArticle.do")
	public String update(Article bean) {
		try {
			bean.setAddDate(DateUtil.getCurrentTime(DateUtil.FULL));
			String imgFile = FileUtil.uploadFile(request, "resfile");
			if (StringUtils.isNoneBlank(imgFile)) {
				bean.setImgFile(imgFile);
			}
			service.update(bean);
			MessageUtil.addRelMessage(request, "更新成功.", "baseAdd");
			return SUCCESS;
		} catch (Exception e) {
			e.printStackTrace();
			MessageUtil.addMessage(request, "更新失败.");
			return ERROR;
		}
	}

	@RequestMapping(value = "/deleteArticle.do")
	public String delete(String ids) {
		try {
			service.delete(Article.class, ids);
			MessageUtil.addRelMessage(request, "操作成功.", "mainquery");
			return SUCCESS;
		} catch (Exception e) {
			e.printStackTrace();
			MessageUtil.addMessage(request, "操作失败.");
			return ERROR;
		}
	}

	@RequestMapping(value = "/queryArticle.do")
	public String query() {
		try {
			// 字段名称集合
			LinkedList<String> parmnames = new LinkedList<String>();
			// 字段值集合
			LinkedList<Object> parmvalues = new LinkedList<Object>();
			Page p = FieldUtil.createPage(request, Article.class, parmnames, parmvalues);

			Page page = service.find(p, Article.class);
			session.setAttribute(Constant.SESSION_PAGE, page);

			request.setAttribute("actionname", actionname);
			request.setAttribute("actionclass", actionclass);
			return "sys/listArticle";
		} catch (Exception e) {
			e.printStackTrace();
			return ERROR;
		}
	}

	@RequestMapping(value = "/queryArticleAll.do")
	public String queryArticleAll() {
		try {
			// 字段名称集合
			LinkedList<String> parmnames = new LinkedList<String>();
			// 字段值集合
			LinkedList<Object> parmvalues = new LinkedList<Object>();
			Page p = FieldUtil.createPage(request, Article.class, parmnames, parmvalues);

			Page page = service.find(p, Article.class);
			session.setAttribute(Constant.SESSION_PAGE, page);

			request.setAttribute("actionname", actionname);
			request.setAttribute("actionclass", actionclass);
			return "sys/queryArticleAll";
		} catch (Exception e) {
			e.printStackTrace();
			return ERROR;
		}
	}

	private ArticleTypeWord typeWordOfType(ArticelType type) {
		List<ArticleTypeWord> allTypeWord = service.findAll(ArticleTypeWord.class);
		ArticleTypeWord curTypeWord = null;
		for (ArticleTypeWord typeWord : allTypeWord) {
			if (typeWord.getName().equals(type.getName())) {
				curTypeWord = typeWord;
			}
		}
		if (curTypeWord == null) {
			curTypeWord = new ArticleTypeWord();
			curTypeWord.setName(type.getName());
		}
		return curTypeWord;
	}
}
