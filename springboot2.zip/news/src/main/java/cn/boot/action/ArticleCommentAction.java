package cn.boot.action;

import java.util.LinkedList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import cn.boot.common.BaseAction;
import cn.boot.entity.ArticleComment;
import cn.boot.service.BizService;
import util.Constant;
import util.FieldUtil;
import util.MessageUtil;
import util.Page;

@Controller
@RequestMapping("/sys")
public class ArticleCommentAction extends BaseAction {
	private String			actionname	= "评论";
	private String			actionclass	= "ArticleComment";
	@Autowired
	private BizService	service;

	@RequestMapping(value = "/add2ArticleComment.do", method = RequestMethod.GET)
	public String add2() {
		request.setAttribute("actionname", actionname);
		request.setAttribute("actionclass", actionclass);
		return "sys/addArticleComment";
	}

	@RequestMapping(value = "/getArticleComment.do", method = RequestMethod.GET)
	public String get(int uid) {
		try {
			ArticleComment temp = (ArticleComment) service.get(ArticleComment.class, uid);
			request.setAttribute("modifybean", temp);

			request.setAttribute("actionname", actionname);
			request.setAttribute("actionclass", actionclass);
			return "sys/modifyArticleComment";
		} catch (Exception e) {
			e.printStackTrace();
			MessageUtil.addMessage(request, "获取信息失败.");
			return ERROR;
		}
	}

	@RequestMapping(value = "/addArticleComment.do")
	public String add(ArticleComment bean) {
		try {
			service.add(bean);
			MessageUtil.addMessage(request, "添加成功.");
			return SUCCESS;
		} catch (Exception e) {
			e.printStackTrace();
			MessageUtil.addMessage(request, "添加失败.");
			return ERROR;
		}

	}

	@RequestMapping(value = "/updateArticleComment.do")
	public String update(ArticleComment bean) {
		try {
			service.update(bean);
			MessageUtil.addRelMessage(request, "更新成功.", "baseAdd");
			return SUCCESS;
		} catch (Exception e) {
			e.printStackTrace();
			MessageUtil.addMessage(request, "更新失败.");
			return ERROR;
		}
	}

	@RequestMapping(value = "/deleteArticleComment.do")
	public String delete(String ids) {
		try {
			service.delete(ArticleComment.class, ids);
			MessageUtil.addRelMessage(request, "操作成功.", "mainquery");
			return SUCCESS;
		} catch (Exception e) {
			e.printStackTrace();
			MessageUtil.addMessage(request, "操作失败.");
			return ERROR;
		}
	}

	@RequestMapping(value = "/queryArticleComment.do")
	public String query() {
		try {
			// 字段名称集合
			LinkedList<String> parmnames = new LinkedList<String>();
			// 字段值集合
			LinkedList<Object> parmvalues = new LinkedList<Object>();
			Page p = FieldUtil.createPage(request, ArticleComment.class, parmnames, parmvalues);

			Page page = service.findArticleComment(p, ArticleComment.class);
			session.setAttribute(Constant.SESSION_PAGE, page);

			request.setAttribute("actionname", actionname);
			request.setAttribute("actionclass", actionclass);
			return "sys/listArticleComment";
		} catch (Exception e) {
			e.printStackTrace();
			return ERROR;
		}
	}
	@RequestMapping(value = "/queryArticleCommentSelf.do")
	public String queryArticleCommentSelf() {
		try {
			// 字段名称集合
			LinkedList<String> parmnames = new LinkedList<String>();
			// 字段值集合
			LinkedList<Object> parmvalues = new LinkedList<Object>();
			Page p = FieldUtil.createPage(request, ArticleComment.class, parmnames, parmvalues);
			
			parmnames.add("user.id");
			parmvalues.add(getSimpleUser().getId());
			
			Page page = service.find(p, ArticleComment.class);
			session.setAttribute(Constant.SESSION_PAGE, page);
			
			request.setAttribute("actionname", actionname);
			request.setAttribute("actionclass", actionclass);
			return "sys/queryArticleCommentSelf";
		} catch (Exception e) {
			e.printStackTrace();
			return ERROR;
		}
	}
}
