package cn.boot.common;

import org.springframework.web.bind.annotation.ControllerAdvice;

@ControllerAdvice(basePackages = "com.biz")
public class ExceptionHandle {
//	@ExceptionHandler(RuntimeException.class)
//	public String error() {
//		return "error";
//	}

	//	@ExceptionHandler(Exception.class)
	//	@ResponseBody
	//	public Map<String, Object> errorMsg(Exception e) {
	//		
	//		Map<String, Object> errorMsgResult = new HashMap<>();
	//		errorMsgResult.put("code", 300);
	//		errorMsgResult.put("msg", e.getMessage());
	//		return errorMsgResult;
	//	}

}
