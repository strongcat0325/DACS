package cn.boot.common;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import org.springframework.beans.factory.annotation.Autowired;

import cn.boot.service.BizService;

@WebListener
public class WebInitListener implements ServletContextListener {
	@Autowired
	private BizService	service;


	@Override
	public void contextDestroyed(ServletContextEvent arg0) {

	}

	@Override
	public void contextInitialized(ServletContextEvent event) {

	}

}
