package cn.boot.common;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;

import util.NumberUtil;
import util.Page;
import util.SearchParamBean;

public abstract class BaseHibernateDao implements BaseDao {

	protected static Logger			log		= Logger.getLogger(BaseHibernateDao.class);

	@PersistenceContext
	protected EntityManager	entityManager;

	protected Session getSession() {
		Session session = (Session) entityManager.getDelegate();
		return session;
	}

	@SuppressWarnings("rawtypes")
	public void deleteByIds(Class clazz, String ids) {
		if (ids != null) {

			String[] temp = ids.split(",");
			if (temp == null || temp.length <= 0) {
				throw new RuntimeException("ids error");
			}
			for (String str : temp) {
				if (!NumberUtil.isNumeric(str)) {
					throw new RuntimeException("ids error");
				}
			}
			String hql = "delete " + clazz.getSimpleName() + " where id in(" + ids + ")";
			updateByHQL(hql);
		}
	}

	public Serializable save(Object model) {
		Session session = getSession();
		return session.save(model);
	}

	public void saveOrUpdate(Object model) {
		Session session = getSession();
		session.saveOrUpdate(model);
	}

	public void update(Object model) {
		Session session = getSession();
		session.update(model);
	}

	public void merge(Object model) {
		Session session = getSession();
		session.merge(model);
	}

	public void delete(Object model) {
		Session session = getSession();
		session.delete(model);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void delete(Class clazz, Serializable id) {
		Session session = getSession();
		session.save(session.load(clazz, id));
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public <T> T get(Class clazz, Serializable id) {
		return (T) getSession().get(clazz, id);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Object load(Class clazz, Serializable id) {
		return getSession().load(clazz, id);
	}

	@SuppressWarnings("rawtypes")
	public List queryByHQL(String hql, Object... values) {
		Session session = getSession();
		Query query = createQuery(session, hql, values);
		return query.list();

	}

	protected Query createQuery(Session session, String hql, Object... values) {
		Query query = session.createQuery(hql);
		if (values != null && values.length > 0) {
			for (int i = 0; i < values.length; i++) {
				query.setParameter(i, values[i]);
			}
		}
		return query;
	}

	@SuppressWarnings("rawtypes")
	public List queryByHQL(String hql) {
		return queryByHQL(hql, new Object[] {});
	}

	public void updateByHQL(String hql, Object... values) {
		Session session = getSession();
		Query query = createQuery(session, hql, values);
		query.executeUpdate();
	}

	public void updateByHQL(String hql, Object values) {
		Session session = getSession();
		Query query = createQuery(session, hql, new Object[] { values });
		query.executeUpdate();
	}

	public void updateByHQL(String hql) {
		Session session = getSession();
		Query query = createQuery(session, hql, new Object[] {});
		query.executeUpdate();
	}

	/**
	 * 通用列表查询,当pn<=-1 且 pageSize<=-1表示查询所有记录
	 * 
	 * @param <T>
	 *            模型类型
	 * @param hql
	 *            Hibernate查询语句
	 * @param pn
	 *            页码 从1开始，
	 * @param pageSize
	 *            每页记录数
	 * @param paramlist
	 *            可变参数列表
	 * @return 模型对象列表
	 */
	public Page list(final Page p, final String name) {
		Session session = getSession();
		SearchParamBean bean = (SearchParamBean) p.getConditonObject();
		LinkedList<String> parmnames = bean.getParmnames();
		LinkedList<Object> parmvalues = bean.getParmvalues();

		StringBuilder sb = new StringBuilder(200);
		sb.append("from " + name + " where 1=1");
		// for (String name : parmnames) {
		// sb.append(" and ").append(name).append("=? ");
		// }
		for (int i = 0; i < parmnames.size(); i++) {
			String fname = parmnames.get(i);
			if (parmvalues.get(i) instanceof String) {
				sb.append(" and ").append(fname).append(" like ? ");
			} else {
				sb.append(" and ").append(fname).append("=? ");
			}
		}
		sb.append(" order by id desc");
		String hql = sb.toString();

		Page temp = queryByPage(hql, parmvalues, (p.getCurrentPageNumber() - 1) * p.getItemsPerPage(), p.getItemsPerPage(), p.getTotalNumber(), session);

		p.setList(temp.getList());
		if (p.getTotalNumber() <= 0) {
			p.setTotalNumber(temp.getTotalNumber());
		}
		return p;

	}

	public Page list(final Page p, final String name, final String orderBy) {
		Session session = getSession();
		SearchParamBean bean = (SearchParamBean) p.getConditonObject();
		LinkedList<String> parmnames = bean.getParmnames();
		LinkedList<Object> parmvalues = bean.getParmvalues();

		StringBuilder sb = new StringBuilder(200);
		sb.append("from " + name + " where 1=1");
		// for (String name : parmnames) {
		// sb.append(" and ").append(name).append("=? ");
		// }
		for (int i = 0; i < parmnames.size(); i++) {
			String fname = parmnames.get(i);
			if (parmvalues.get(i) instanceof String) {
				sb.append(" and ").append(fname).append(" like ? ");
			} else {
				sb.append(" and ").append(fname).append("=? ");
			}
		}
		if (StringUtils.isNotBlank(orderBy)) {
			sb.append(" order by " + orderBy);
		} else {
			sb.append(" order by id desc");
		}
		String hql = sb.toString();

		Page temp = queryByPage(hql, parmvalues, (p.getCurrentPageNumber() - 1) * p.getItemsPerPage(), p.getItemsPerPage(), p.getTotalNumber(), session);

		p.setList(temp.getList());
		if (p.getTotalNumber() <= 0) {
			p.setTotalNumber(temp.getTotalNumber());
		}
		return p;

	}

	@SuppressWarnings("rawtypes")
	protected Page queryByPage(final String listHql, final List<? extends Object> params, final Integer firstResult, final Integer maxResults,
			final Long totalCount, Session session) {
		if (listHql == null || listHql.trim().length() == 0) {
			return null;
		}
		Page page = new Page();
		// Query listQuery = this.createQuery(listHql, params);
		Query listQuery = session.createQuery(listHql);
		if (params != null && !params.isEmpty()) {
			int size = params.size();
			for (int i = 0; i < size; i++) {
				listQuery.setParameter(i, params.get(i));
			}
		} else {
			if (params != null && !params.isEmpty()) {
				listQuery.setParameter(0, params);
			}
		}
		// 设置开始检索的起始记录
		listQuery.setFirstResult(firstResult);
		// 设置每次检索返回的最大对象数
		listQuery.setMaxResults(maxResults);
		List list = listQuery.list();
		page.setList(list);

		// 如果总数已经存在，则不查询
		if (totalCount > 0) {
			page.setTotalNumber(totalCount);
		} else {
			String countHql = listHql;
			int order_index = countHql.toUpperCase().lastIndexOf("ORDER");
			if (order_index != -1) {
				countHql = countHql.substring(0, order_index);
			}

			// 通过转成SQL来进行查询，解决hql不能在distinct，group by结果集上使用count的问题
			//			QueryTranslatorImpl queryTranslator = new QueryTranslatorImpl(null, countHql, Collections.EMPTY_MAP,
			//					(org.hibernate.engine.SessionFactoryImplementor) session.getSessionFactory());
			//			queryTranslator.compile(Collections.EMPTY_MAP, false);
			//			countHql = new StringBuffer("select count(*) from (").append(countHql).append(") tmp_count_table").toString();
			countHql = new StringBuffer("select count(*) ").append(countHql).toString();
			Query countQuery = session.createQuery(countHql);
			if (params != null && !params.isEmpty()) {
				int size = params.size();
				for (int i = 0; i < size; i++) {
					countQuery.setParameter(i, params.get(i));
				}
			}

			page.setTotalNumber(Long.valueOf(countQuery.uniqueResult().toString()));

		}

		return page;
	}

	/**
	 * 根据查询条件返回唯一一条记录
	 * 
	 * @param <T>
	 *            返回类型
	 * @param hql
	 *            Hibernate查询语句
	 * @param paramlist
	 *            参数列表
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public <T> T unique(final String hql, final Object... paramlist) {

		Session session = getSession();
		Query query = createQuery(session, hql, paramlist);
		return (T) query.uniqueResult();
	}

	@SuppressWarnings("rawtypes")
	public List findAll(Class clazz, Map<String, Object> params) {
		String hql = "from " + clazz.getSimpleName();
		if (params == null || params.size() == 0) {
			return queryByHQL(hql);
		}
		Object[] objs = new Object[params.size()];
		hql += " where 1=1";
		int index = 0;
		for (String name : params.keySet()) {
			hql += " and " + name + "=?";
			objs[index++] = params.get(name);
		}
		return queryByHQL(hql, objs);
	}

}
