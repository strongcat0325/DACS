package cn.boot.common;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;

import javax.imageio.ImageIO;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.google.code.kaptcha.Constants;
import com.google.code.kaptcha.impl.DefaultKaptcha;

@Controller
//@PropertySource("classpath:my.properties")
public class CommonAction {

	@Autowired
	DefaultKaptcha	defaultKaptcha;

	//	@Value("${image.save}")
	//	private String	imageSavePath;

	@RequestMapping(value = "/")
	public String add2() {
		return "redirect:/exit.jsp";
	}

	//	@GetMapping(value = "/attached/image/{imagePath}", produces = { MediaType.IMAGE_GIF_VALUE, MediaType.IMAGE_JPEG_VALUE, MediaType.IMAGE_PNG_VALUE })
	//	public ResponseEntity<Resource> imageAttached(@PathVariable("imagePath") String imagePath) {
	//		try {
	//			String fileName = imageSavePath + File.separator + "image" + File.separator + imagePath;
	//			File file = new File(fileName);
	//			if (!file.exists()) {
	//				file = new File(imageSavePath + File.separator + "no.jpg");
	//			}
	//			InputStream in = new FileInputStream(file);
	//			InputStreamResource inputStreamResource = new InputStreamResource(in);
	//			HttpHeaders headers = new HttpHeaders();
	//			return new ResponseEntity<Resource>(inputStreamResource, headers, HttpStatus.OK);
	//		} catch (Exception e) {
	//			e.printStackTrace();
	//			return null;
	//		}
	//	}
	//
	//	@GetMapping(value = "/attached/image", produces = { MediaType.IMAGE_GIF_VALUE, MediaType.IMAGE_JPEG_VALUE, MediaType.IMAGE_PNG_VALUE })
	//	public ResponseEntity<Resource> imageAttached() {
	//		try {
	//			File file = new File(imageSavePath + File.separator + "image" + File.separator + "no.jpg");
	//
	//			InputStream in = new FileInputStream(file);
	//			InputStreamResource inputStreamResource = new InputStreamResource(in);
	//			HttpHeaders headers = new HttpHeaders();
	//			return new ResponseEntity<Resource>(inputStreamResource, headers, HttpStatus.OK);
	//		} catch (Exception e) {
	//			e.printStackTrace();
	//			return null;
	//		}
	//	}
	//
	//	@GetMapping(value = "/resource/{imagePath}", produces = { MediaType.IMAGE_GIF_VALUE, MediaType.IMAGE_JPEG_VALUE, MediaType.IMAGE_PNG_VALUE })
	//	public ResponseEntity<Resource> imageResource(@PathVariable("imagePath") String imagePath) {
	//		try {
	//			String fileName = imageSavePath + File.separator + imagePath;
	//			File file = new File(fileName);
	//			if (!file.exists()) {
	//				file = new File(imageSavePath + File.separator + "no.jpg");
	//			}
	//			InputStream in = new FileInputStream(file);
	//			InputStreamResource inputStreamResource = new InputStreamResource(in);
	//			HttpHeaders headers = new HttpHeaders();
	//			return new ResponseEntity<Resource>(inputStreamResource, headers, HttpStatus.OK);
	//		} catch (Exception e) {
	//			e.printStackTrace();
	//			return null;
	//		}
	//	}



	/**
	 * 2、生成验证码
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @throws Exception
	 */
	@RequestMapping("/checkcode")
	public void defaultKaptcha(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws Exception {
		byte[] captchaChallengeAsJpeg = null;
		ByteArrayOutputStream jpegOutputStream = new ByteArrayOutputStream();
		try {
			// 生产验证码字符串并保存到session中
			String createText = defaultKaptcha.createText();
			httpServletRequest.getSession().setAttribute(Constants.KAPTCHA_SESSION_KEY, createText);
			// 使用生产的验证码字符串返回一个BufferedImage对象并转为byte写入到byte数组中
			BufferedImage challenge = defaultKaptcha.createImage(createText);
			ImageIO.write(challenge, "jpg", jpegOutputStream);
		} catch (IllegalArgumentException e) {
			httpServletResponse.sendError(HttpServletResponse.SC_NOT_FOUND);
			return;
		}

		// 定义response输出类型为image/jpeg类型，使用response输出流输出图片的byte数组
		captchaChallengeAsJpeg = jpegOutputStream.toByteArray();
		httpServletResponse.setHeader("Cache-Control", "no-store");
		httpServletResponse.setHeader("Pragma", "no-cache");
		httpServletResponse.setDateHeader("Expires", 0);
		httpServletResponse.setContentType("image/jpeg");
		ServletOutputStream responseOutputStream = httpServletResponse.getOutputStream();
		responseOutputStream.write(captchaChallengeAsJpeg);
		responseOutputStream.flush();
		responseOutputStream.close();
	}

	/**
	 * 3、校对验证码
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @return
	 */
	@RequestMapping("/imgvrifyControllerDefaultKaptcha")
	public ModelAndView imgvrifyControllerDefaultKaptcha(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
		ModelAndView andView = new ModelAndView();
		String rightCode = (String) httpServletRequest.getSession().getAttribute("rightCode");
		String tryCode = httpServletRequest.getParameter("tryCode");
		System.out.println("rightCode:" + rightCode + " ———— tryCode:" + tryCode);
		if (!rightCode.equals(tryCode)) {
			andView.addObject("info", "错误的验证码");
			andView.setViewName("index");
		} else {
			andView.addObject("info", "登录成功");
			andView.setViewName("success");
		}
		return andView;
	}

}
