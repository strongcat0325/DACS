package cn.boot.common;

import org.apache.log4j.Logger;
 
public abstract class BaseService {

	protected static Logger log = Logger.getLogger(BaseService.class);
	 
}
