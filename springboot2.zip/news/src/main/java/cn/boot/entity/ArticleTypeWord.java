package cn.boot.entity;

import util.FD;

import javax.persistence.*;

@Entity
@Table(name = "t_articel_type_words")
public class ArticleTypeWord {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", unique = true, nullable = false)
    private Integer	id;
    @FD("栏目")
    @Column(unique = true)
    private String	name;

    @FD("关键词表")
    private String words;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getWords() {
        return words;
    }

    public void setWords(String words) {
        this.words = words;
    }

    @Override
    public String   toString() {
        return "ArticleTypeWord{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", words='" + words + '\'' +
                '}';
    }
}
