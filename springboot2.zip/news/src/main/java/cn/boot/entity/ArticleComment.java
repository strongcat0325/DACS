package cn.boot.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import cn.boot.entity.main.SimpleUser;
import util.FD;

@Entity
@Table(name = "t_article_comment")
public class ArticleComment {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", unique = true, nullable = false)
	private Integer			id;
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "articleId")
	@FD("新闻")
	private Article			article;
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "userId")
	@FD("用户")
	private SimpleUser	user;

	@FD("评论")
	@Column(length = 5000)
	private String			comment;
	@FD("日期")
	private String			addDate;

	@FD("举报次数")
	private Integer			rcount;

	@Column(updatable = false)
	private String			userread;

	@Transient
	private List				list;

	public List getList() {
		return list;
	}

	public void setList(List list) {
		this.list = list;
	}

	public Integer getRcount() {
		return rcount;
	}

	public void setRcount(Integer rcount) {
		this.rcount = rcount;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Article getArticle() {
		return article;
	}

	public void setArticle(Article article) {
		this.article = article;
	}

	public SimpleUser getUser() {
		return user;
	}

	public void setUser(SimpleUser user) {
		this.user = user;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getAddDate() {
		return addDate;
	}

	public void setAddDate(String addDate) {
		this.addDate = addDate;
	}

	public String getUserread() {
		return userread;
	}

	public void setUserread(String userread) {
		this.userread = userread;
	}

}
