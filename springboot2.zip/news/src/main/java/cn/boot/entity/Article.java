package cn.boot.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.jsoup.Jsoup;

import util.FD;

@Entity
@Table(name = "t_article")
public class Article {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", unique = true, nullable = false)
	private Integer			id;
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "articelTypeId")
	@FD("栏目")
	private ArticelType	articelType;

	@FD("图片")
	private String			imgFile;
	@FD("标题")
	private String			title;
	@FD("内容")
	@Column(length = 5000)
	private String			content;
	@FD("发布日期")
	private String			addDate;

	@FD("浏览量")
	@Column(updatable = false)
	private Integer			viewCount;
	@FD("点赞数")
	@Column(updatable = false)
	private Integer			zanCount;
	@FD("踩")
	@Column(updatable = false)
	private Integer			caiCount;
	@FD("收藏量")
	@Column(updatable = false)
	private Integer			favCount;

	@Transient
	public String getNote() {
		String text = Jsoup.parse(content).text();
		if (text.length() > 100) {
			text = text.substring(0, 100);
		}
		return text;
	}

	public Integer getFavCount() {
		return favCount;
	}

	public void setFavCount(Integer favCount) {
		this.favCount = favCount;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public ArticelType getArticelType() {
		return articelType;
	}

	public void setArticelType(ArticelType articelType) {
		this.articelType = articelType;
	}

	public String getImgFile() {
		return imgFile;
	}

	public void setImgFile(String imgFile) {
		this.imgFile = imgFile;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getAddDate() {
		return addDate;
	}

	public void setAddDate(String addDate) {
		this.addDate = addDate;
	}

	public Integer getViewCount() {
		return viewCount;
	}

	public void setViewCount(Integer viewCount) {
		this.viewCount = viewCount;
	}

	public Integer getZanCount() {
		return zanCount;
	}

	public void setZanCount(Integer zanCount) {
		this.zanCount = zanCount;
	}

	public Integer getCaiCount() {
		return caiCount;
	}

	public void setCaiCount(Integer caiCount) {
		this.caiCount = caiCount;
	}

}
