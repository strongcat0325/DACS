package cn.boot.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import util.FD;

@Entity
@Table(name = "t_database_file")
public class DatabaseFile {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", unique = true, nullable = false)
	private int			id;
	@FD("备份文件")
	private String	filePath;
	@FD("备份时间")
	private String	addDate;

	public int getId() {
		return id;
	}

	public String getFilePath() {
		return filePath;
	}

	public String getAddDate() {
		return addDate;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public void setAddDate(String addDate) {
		this.addDate = addDate;
	}

}
