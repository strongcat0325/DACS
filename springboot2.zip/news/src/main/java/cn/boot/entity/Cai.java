package cn.boot.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import cn.boot.entity.main.SimpleUser;
import util.FD;

@Entity
@Table(name = "t_cai")
public class Cai {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", unique = true, nullable = false)
	private Integer			id;
	@FD("新闻")
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "articleId")
	private Article			article;
	@FD("用户")
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "userId")
	private SimpleUser	user;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Article getArticle() {
		return article;
	}

	public void setArticle(Article article) {
		this.article = article;
	}

	public SimpleUser getUser() {
		return user;
	}

	public void setUser(SimpleUser user) {
		this.user = user;
	}

}
