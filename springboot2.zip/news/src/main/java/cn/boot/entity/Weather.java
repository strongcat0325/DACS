package cn.boot.entity;

public class Weather {
	private Integer	id;
	private String	city;
	private String	addDate;
	private String	fengxiang;
	private String	fengli;
	private Integer	whign;
	private Integer	wlow;
	private String	wtype;

	private String	icon1;
	private String	icon2;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getAddDate() {
		return addDate;
	}

	public void setAddDate(String addDate) {
		this.addDate = addDate;
	}

	public String getFengxiang() {
		return fengxiang;
	}

	public void setFengxiang(String fengxiang) {
		this.fengxiang = fengxiang;
	}

	public String getFengli() {
		return fengli;
	}

	public void setFengli(String fengli) {
		this.fengli = fengli;
	}

	public Integer getWhign() {
		return whign;
	}

	public void setWhign(Integer whign) {
		this.whign = whign;
	}

	public Integer getWlow() {
		return wlow;
	}

	public void setWlow(Integer wlow) {
		this.wlow = wlow;
	}

	public String getWtype() {
		return wtype;
	}

	public void setWtype(String wtype) {
		this.wtype = wtype;
	}

	public String getIcon1() {
		return icon1;
	}

	public void setIcon1(String icon1) {
		this.icon1 = icon1;
	}

	public String getIcon2() {
		return icon2;
	}

	public void setIcon2(String icon2) {
		this.icon2 = icon2;
	}

}
