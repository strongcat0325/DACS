package cn.boot.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.jsoup.Jsoup;

import util.FD;

@Entity
@Table(name = "t_news")
public class News {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", unique = true, nullable = false)
	private Integer	id;
	@FD("主题")
	private String	title;
	@FD("日期")
	private String	addDate;
	@FD("内容")
	@Column(length = 5000)
	private String	content;

	@Transient
	public String getNote() {
		String text = Jsoup.parse(content).text();
		if (text.length() > 250) {
			text = text.substring(0, 250);
		}
		return text;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAddDate() {
		return addDate;
	}

	public void setAddDate(String addDate) {
		this.addDate = addDate;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

}
