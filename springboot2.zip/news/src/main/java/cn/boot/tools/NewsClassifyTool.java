package cn.boot.tools;

import cn.boot.entity.ArticelType;
import cn.boot.entity.Article;
import com.qianxinyao.analysis.jieba.keyword.Keyword;

import java.util.ArrayList;
import java.util.List;


public class NewsClassifyTool {
    // 余弦向量空间维数
    private static final int vectorNum = 10;
    // 余弦相似度最小满足阈值
    private static final double minSupportValue = 0.45;

    /**
     * 根据求得的向量空间计算余弦相似度值
     *
     * @param vectorDimension 已求得的测试数据的特征向量值
     * @return
     */
    private static double calCosValue(double[] vectorDimension) {
        if (vectorDimension.length == 0) {
            return 0.0;
        }
        double result;
        double num1;
        double num2;
        double temp1;
        double temp2;
        // 标准的特征向量，每个维度上都为1
        double[] standardVector;

        standardVector = new double[vectorDimension.length];
        for (int i = 0; i < vectorDimension.length; i++) {
            standardVector[i] = 1;
        }

        temp1 = 0;
        temp2 = 0;
        num1 = 0;

        for (int i = 0; i < vectorDimension.length; i++) {
            // 累加分子的值
            num1 += vectorDimension[i] * standardVector[i];

            // 累加分母的值
            temp1 += vectorDimension[i] * vectorDimension[i];
            temp2 += standardVector[i] * standardVector[i];
        }

        num2 = Math.sqrt(temp1) * Math.sqrt(temp2);
        // 套用余弦定理公式进行计算
        result = num1 / num2;

        return result;
    }

    /**
     * 计算特征向量空间值
     */
    private static double[] calVectorDimension(List<Keyword> vectorWords, List<String> hasExisted) {
        List<Double> vectorDimensionList = new ArrayList<>();
        // 逐个比较特征向量词
        for (Keyword entry : vectorWords) {
            if (hasExisted.contains(entry.getName())) {
                vectorDimensionList.add(entry.getTfidfvalue());
            }
        }
        double[] vectorDimension = new double[vectorDimensionList.size()];
        int index = 0;
        for (double dimensionValue : vectorDimensionList) {
            vectorDimension[index++] = dimensionValue;
        }
        return vectorDimension;
    }

    /**
     * 进行新闻分类
     *
     */
    public static double newsClassify(Article bean, List<String> curTypeWordList) {
        // 进行分词操获取高频词汇
        List<Keyword> wordList = JiebaAnalysisTool.classify(bean);

        double[] vectorDimensions = calVectorDimension(wordList, curTypeWordList);
        double result = calCosValue(vectorDimensions);

        return result;
    }
}
