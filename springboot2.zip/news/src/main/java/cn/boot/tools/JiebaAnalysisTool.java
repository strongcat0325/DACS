package cn.boot.tools;

import cn.boot.entity.Article;
import com.qianxinyao.analysis.jieba.keyword.Keyword;
import com.qianxinyao.analysis.jieba.keyword.TFIDFAnalyzer;

import java.util.List;

public class JiebaAnalysisTool {//分词算法
    private static final int topN = 10;

    public static List<Keyword> classify(Article bean) {
        TFIDFAnalyzer analyzer = new TFIDFAnalyzer();
        String content = DeleteHTMLTagsTool.getTextFromHtml(bean.getContent());
        // 分词，去除html标签
        List<Keyword> analysisRes = analyzer.analyze(content, topN);
        return analysisRes;
    }
}
